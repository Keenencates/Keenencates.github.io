// File: binary_tree.h
// Implementation of treap using binary tree from lecture.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 06    Date assigned:  11/09/2015
// Programmer: Keenen Cates  Date completed: 11/23/2015
#ifndef _BINARY_TREE_H
#define _BINARY_TREE_H
/*Start of Includes*/
#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>
/*End of Includes*/
/*Start of Class Def*/
template <typename T>
class Binary_Tree {
public:
  Binary_Tree();
  Binary_Tree(const Binary_Tree& source);
  ~Binary_Tree();

  Binary_Tree<T>& operator=(Binary_Tree source);

  friend void swap(Binary_Tree<T>& b1, Binary_Tree<T>& b2);
  
  void insert(const T& item);
  int size() const;
  int height() const;
  bool find(const T& item) const;
  std::string to_string() const;
  
private:

  struct BTNode {
    T data;
	int priority;
    BTNode* left;
    BTNode* right;
	BTNode* parent;

    BTNode(const T& d = T(), BTNode* l = 0, BTNode* r = 0, BTNode* p = 0) : data(d), left(l), right(r), parent(p) {}  // assigns all member variables
  };

  void node_add(BTNode* subtree, BTNode* new_node);
  bool node_find(BTNode* subtree, const T& item) const;
  int node_size(BTNode* subtree) const;
  int node_height(BTNode* subtree) const;
  void node_string(BTNode* subtree, std::ostream & out) const;
  void node_kill(BTNode* subtree);
  BTNode* node_copy(BTNode* subtree);
  void SetLeft(BTNode* child, BTNode* parent);
  void SetRight(BTNode* child, BTNode* parent);
  void rotate_left(BTNode* n);
  void rotate_right(BTNode* n);
  
  BTNode* root;
};
/*End of Class Def*/

template <typename T>
Binary_Tree<T>::Binary_Tree() {
  root = 0;    // empty tree
}

template <typename T>
Binary_Tree<T>::Binary_Tree(const Binary_Tree& source) {
  root = node_copy(source.root);
}

template <typename T>
Binary_Tree<T>::~Binary_Tree() {
  node_kill(root);
}

template <typename T>
Binary_Tree<T> &
Binary_Tree<T>::operator=(Binary_Tree source) {
  swap(*this, source);
}

template <typename T>
void
Binary_Tree<T>::insert(const T& item) {
  BTNode* new_node = new BTNode(item);
  if (root == 0) {
    root = new_node;
	root->parent = 0;
	root->priority = rand();
  } else {
    node_add(root, new_node);
  }
  new_node->priority = rand();
  while(new_node != root && new_node->priority > new_node->parent->priority){
	  if(new_node == new_node->parent->left){
		  rotate_right(new_node);
	  }
	  if(new_node == new_node->parent->right){
		  rotate_left(new_node);
	  }
  }
}

template <typename T>
bool
Binary_Tree<T>::find(const T& item) const {
  return node_find(root, item);
}

template <typename T>
int
Binary_Tree<T>::size() const {
  return node_size(root);
}

template <typename T>
int
Binary_Tree<T>::height() const {
  return node_height(root);
}

template <typename T>
std::string
Binary_Tree<T>::to_string() const {
  std::ostringstream ss;

  node_string(root, ss);
  return ss.str();
}

/////////////////////////////////////////////////////////
//   Private helper functions below here
/////////////////////////////////////////////////////////


template <typename T>
void
Binary_Tree<T>::node_add(BTNode* subtree, BTNode* new_node) {
  if (new_node->data < subtree->data ||
      (new_node->data == subtree->data && rand() % 2 == 0) ) {   // to the left
    if (subtree->left == 0) {              // and there's room
      SetLeft(new_node, subtree);
    } else {                               // someone else's problem
      node_add(subtree->left, new_node);
    }
  } else { // to the right
    if (subtree->right == 0) {             // and there's room
      SetRight(new_node, subtree);
    } else {
      node_add(subtree->right, new_node);
    }
  }
}

template <typename T>
bool
Binary_Tree<T>::node_find(BTNode* subtree, const T& item) const {
  if (subtree == 0) {
    return false;
  }
  if (subtree->data == item) {
    return true;
  }
  if (item < subtree->data)
    return node_find(subtree->left, item);
  else
    return node_find(subtree->right, item);
}

template <typename T>
int
Binary_Tree<T>::node_size(BTNode* subtree) const {
  if (subtree == 0)
    return 0;
  else
    return 1 + node_size(subtree->left) + node_size(subtree->right);
}

template <typename T>
int
Binary_Tree<T>::node_height(BTNode* subtree) const {
  if (subtree == 0)
    return 0;
  else {
    int lh = node_height(subtree->left);
    int rh = node_height(subtree->right);
    
    int max = (lh > rh) ? lh : rh;

    return 1+max;
  }
}

template <typename T>
void
Binary_Tree<T>::node_string(BTNode* subtree, std::ostream & out) const {
  if (subtree == 0)
    return;
  node_string(subtree->left, out);
  out << subtree->data << std::endl;
  node_string(subtree->right, out);
}

template <typename T>
void
Binary_Tree<T>::node_kill(BTNode* subtree) {
  if (subtree == 0)
    return;
  node_kill(subtree->left);
  node_kill(subtree->right);
  delete subtree;
}

template <typename T>
typename Binary_Tree<T>::BTNode*
Binary_Tree<T>::node_copy(BTNode* subtree) {
  if (subtree == 0)
    return 0;

  return new BTNode(subtree->data, node_copy(subtree->left), node_copy(subtree->right), subtree);
}

template <typename T>
void swap(Binary_Tree<T>& b1, Binary_Tree<T>& b2) {
  std::swap(b1.root, b2.root);
}

/*SetLeft - Sets childs parent, and parents left child*/
template <typename T>
void 
Binary_Tree<T>::SetLeft(BTNode* child, BTNode* parent){
	child->parent = parent;
	parent->left = child;
}

/*SetRight - Sets childs parent, and parents right child*/
template <typename T>
void 
Binary_Tree<T>::SetRight(BTNode* child, BTNode* parent){
	child->parent = parent;
	parent->right = child;
}
/*rotateRight - Does a right rotation of the binary tree, as according to the diagram.*/
template <typename T>
void 
Binary_Tree<T>::rotate_right(BTNode* n){
	BTNode* a = n->parent;
	BTNode* b = n;
	BTNode* alpha = n->left;
	BTNode* beta = n->right;
	BTNode* gamma = n->parent->right;
	BTNode* initPtr;
	bool isroot = false;
	//root
	if(a == root){
		isroot = true;
	}
	if(!isroot){
		initPtr = a->parent;
		if(initPtr->right == a)
			initPtr->right = b;
		if(initPtr->left == a)
			initPtr->left = b;
	}
	//b
	b->parent = a->parent;
	b->left = a;
	b->right = alpha;
	//a
	a->parent = b;
	a->right = gamma;
	a->left = beta;
	//alpha
	if(alpha)
		alpha->parent = b;
	//beta
	if(beta)
		beta->parent = a;
	//gamma
	if(gamma)
		gamma->parent = a;
	if(isroot)
		root = b;
}
/*leftRotate - Does a left rotation to the binary tree, as according to the diagram.*/
template <typename T>
void 
Binary_Tree<T>::rotate_left(BTNode* n){
	BTNode* a = n;
	BTNode* b = n->parent;
	BTNode* alpha = n->parent->left;
	BTNode* beta = n->left;
	BTNode* gamma = n->right;
	BTNode* initPtr;
	bool isroot = false;
	//root
	if(n->parent == root){
		isroot = true;
	}
	if(!isroot){
		initPtr = b->parent;
		if(initPtr->right == b)
			initPtr->right = a;
		if(initPtr->left == b)
			initPtr->left = a;
	}
	//a
	a->parent = b->parent;
	a->right = gamma;
	a->left = b;
	//b
	b->parent = a;
	b->left = alpha;
	b->right = beta;
	//alpha
	if(alpha)
		alpha->parent = b;
	//beta
	if(beta)
		beta->parent = b;
	//gamma
	if(gamma)
		gamma->parent = a;
	if(isroot)
		root = a;
}
#endif
