// File: project6.cpp
// Driver for treap.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 06    Date assigned:  11/09/2015
// Programmer: Keenen Cates  Date completed: 11/23/2015
#include <iostream>
#include "binary_tree.h"
#include <ctime>
#include <cstdlib>

using namespace std;

int main(){
	Binary_Tree<int> tree;
	Binary_Tree<int> tree2;
	srand(time(0));
	for(int i = 0; i < 1000; i++){
		tree.insert(i);
	}
	cout << "tree height for elements in order: " << tree.height() << endl;
}