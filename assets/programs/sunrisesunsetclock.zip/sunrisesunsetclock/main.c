/*File: main.c
 *Description: Find sunrise and sunset time in local timezones
 *
 *--------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment: #1            Date assigned: 1/21/2015
 *Programmer: Keenen Cates Date completed: 1/23/2015
 */

 /*Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*Constant Definition*/
#define PI 3.1415926

/*Main*/
int main()
{
    /*Variables*/
    double gamma;
    double eqt;
    double declination;
    double hour_angle;
    double sunrise;
    double sunset;
    int sunrise_hour;
    int sunrise_minute;
    int sunset_hour;
    int sunset_minute;

    /*User inputted variables*/
    double latitude;
    double longitude;
    double timezone;
    double day;


    /*Program banner and description*/
    printf("SUNRISE, SUNSET\n");
    printf("This program will calculate sunrise and sunset times for any date and\nlocation\n");

    /*Ask user for data (latitude, longitude, timezone, and day)*/
    printf("\nEnter latitude: ");
    scanf("%lf", &latitude);

    printf("Enter longitude: ");
    scanf("%lf", &longitude);

    printf("Enter timezone: ");
    scanf("%lf", &timezone);

    printf("Enter day of year: ");
    scanf("%lf", &day);

    /*Find gamma (day of the year converted into an angle in radians (represented by "gamma") needs the day)*/
    gamma = (((2 * PI)/(365))*(day - 1));

    //printf("gamma is equal to %g\n", gamma); /*for intermediate checking*/

    /*Find eqt (equation of time in minutes (represented by "eqt") needs gamma)*/
    eqt = (229.18 * (0.000075 + 0.001868 * cos(gamma) - 0.032077 * sin(gamma) - 0.014615 * cos(2 * gamma) - 0.040849 * sin(2 * gamma)));

    //printf("eqt is equal to %g\n", eqt); /*for intermediate checking*/

    /*Find declination (declination of the sun in radians (represented by "declination") needs gamma)*/
    declination = (0.006918 - 0.399912 * cos(gamma) + 0.070257 * sin(gamma)
                   - 0.006758 * cos(2 * gamma) + 0.000907 * sin(2 * gamma)
                   - 0.002697 * cos(3 * gamma) + 0.00148 * sin(3 * gamma));

    //printf("declination  is equal to %g\n", declination); /*for intermediate checking*/

    /*Find hour_angle (hour angle of the sun in degrees (represented by "hour_angle") needs latitude, declination, and PI)*/
    hour_angle = (acos(((cos(1.5853)) / ((cos(latitude * (PI / 180))) * cos(declination)))
                       - ((tan(latitude * (PI / 180))) * tan(declination))) * (180 / PI));

    //printf("hour_angle is equal to %g\n", hour_angle); /*for intermediate checking*/

    /*Find sunrise (time in local minutes of sunrise (represented by "sunrise") needs longitude, hour_angle, eqt, and timezone*/
    sunrise = (720 + 4 * (longitude - hour_angle) - eqt - 60 * timezone);

    //printf("sunrise is equal to %g\n", sunrise); /*for intermediate checking*/

    /*Find sunset (time in local minutes of sunrise (represented by "sunset") needs longitude, hour_angle, eqt, and timezone*/
    sunset = (720 + 4 * (longitude + hour_angle) - eqt - 60 * timezone);

    //printf("sunset is equal to %g\n", sunset); /*for intermediate checking*/

    /*Convert to local time*/
    sunrise_hour = (abs(sunrise / 60)); /*Find local hour (represented by "sunrise/set_hour") needs sunrise/set*/
    sunset_hour = (abs(sunset / 60));

    sunrise_minute = (abs(sunrise - (sunrise_hour * 60))); /*Find local minute (represented by "sunrise/set_minute") needs sunrise/set and sunrise/set_hour*/
    sunset_minute = (abs(sunset - (sunset_hour * 60)));

    /*Output (Sunrise and Sunset)*/
    printf("\nSunrise: %d:%02d\n", sunrise_hour, sunrise_minute);
    printf("Sunset: %d:%02d\n", sunset_hour, sunset_minute);

    return 0;
}
