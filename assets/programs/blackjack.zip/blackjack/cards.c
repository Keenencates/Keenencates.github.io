#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <ctype.h>
#include "cards.h"

/*Card Functions*/
card_t create_card(char suit, int value){
    card_t card;
    suit = toupper(suit);
    if(suit == 'H' || suit == 'D' || suit == 'S' || suit == 'C')
        card.suit = suit;
    if(value <= 13 && value >= 1)
        card.value = value;
    else{
        card.suit = 'C';
        card.value = 2;
    }
    return card;
}

void print_card(card_t card){
    if(card.value == 1)
        printf("Ace of ");
    if(card.value > 1 && card.value < 11)
        printf("%d of ", card.value);
    if(card.value == 11)
        printf("Jack of ");
    if(card.value == 12)
        printf("Queen of ");
    if(card.value == 13)
        printf("King of ");
    if(card.suit == 'H')
        printf("Hearts\n");
    if(card.suit == 'C')
        printf("Clubs\n");
    if(card.suit == 'S')
        printf("Spades\n");
    if(card.suit == 'D')
        printf("Diamonds\n");
}

int points(card_t card){
    if(card.value >= 11 && card.value <= 13)
        return 10;
    return card.value;
}

/*Shoe Functions*/
shoe_t create_shoe(int numDecks){
    int i, j = 1;
    card_t card;
    shoe_t shoe;
    shoe.deckIndex = 0;
    shoe.numDecks = numDecks;
    shoe.deck = (card_t *)calloc(shoe.numDecks*52, (sizeof(card_t)));
    for(i = 0; i < (shoe.numDecks*52)/4; i++){
        card = create_card('h' , j);
        shoe.deck[i] = card;
        if(j == 13)
            j = 0;
        j++;
    }

    j = 1;
    for(i = (shoe.numDecks*52)/4; i < (shoe.numDecks*52)/2; i++){
        card = create_card('s' , j);
        shoe.deck[i] = card;
        if(j == 13)
            j = 0;
        j++;
    }

    j = 1;
    for(i = (shoe.numDecks*52)/2; i < (3*(shoe.numDecks*52))/4; i++){
        card = create_card('c' , j);
        shoe.deck[i] = card;
        if(j == 13)
            j = 0;
        j++;
    }

    j = 1;
    for(i = (3*(shoe.numDecks*52))/4; i < (shoe.numDecks*52); i++){
        card = create_card('d' , j);
        shoe.deck[i] = card;
        if(j == 13)
            j = 0;
        j++;
    }
    reshuffle(shoe);
    return shoe;
}

card_t draw_card(shoe_t *shoe){
    card_t card;
    if(cards_left(* shoe) == 0){
        reshuffle(* shoe);
        (* shoe).deckIndex = 0;
    }
    card = (* shoe).deck[(* shoe).deckIndex];
    (* shoe).deckIndex += 1;
    return card;
}

int cards_left(shoe_t shoe){
    return((shoe.numDecks*52) - (shoe.deckIndex));
}

void reshuffle(shoe_t shoe){
    int i, j;
    card_t k;
    srand(time(0));
    for(i=0; i<shoe.numDecks*52; i++) {
        j = i + rand()%(shoe.numDecks*52-i);
        k = shoe.deck[i];
        shoe.deck[i] = shoe.deck[j];
        shoe.deck[j] = k;
    }
    printf("\nSHUFFLING!\n");
}

void free_shoe(shoe_t *shoe){
    free(((* shoe).deck));
}

hand_t empty_hand(void){
    hand_t hand;
    hand.numCardsInHand = 0;
    return hand;
}

void print_hand(hand_t hand){
    int i;
    printf("Your cards:\n");
    for(i = 0; i < hand.numCardsInHand; i++)
        print_card(hand.cardsInHand[i]);
}

void add_card_to_hand(hand_t *hand, card_t card){
    (* hand).cardsInHand[(* hand).numCardsInHand] = card;
    (* hand).numCardsInHand += 1;
}

int blackjack_points(hand_t hand){
    int i, hand_total = 0;
    card_t card;
    for(i = 0; i < hand.numCardsInHand; i++){
        card = hand.cardsInHand[i];
        hand_total +=  points(card);
        if(card.value == 1 && hand_total <= 11)
            hand_total += 10;
    }
    return hand_total;
}

void deal_hand(shoe_t *shoe, hand_t *user_hand, hand_t *dealer_hand){
    (* user_hand) = empty_hand();
    (* dealer_hand) = empty_hand();
    add_card_to_hand(user_hand, draw_card(shoe));
    add_card_to_hand(dealer_hand, draw_card(shoe));
    add_card_to_hand(user_hand, draw_card(shoe));
    add_card_to_hand(dealer_hand, draw_card(shoe));
}

int get_user_bet(int total_money){
    int user_bet;
    do{
        printf("\nEnter your bet (negative to quit): ");
        scanf(" %d", &user_bet);
    }while(user_bet > total_money);
    return user_bet;
}

int get_decks(void){
    int num_decks;
    do{
        printf("\nHow many decks do you wish to play with (1-10)? ");
        scanf(" %d", &num_decks);
    }while(num_decks > 10 || num_decks < 1);
    return num_decks;
}

void print_greeting(void){
    printf("Welcome to Blackjack!\n");
}

char hit_or_stand(void){
    char choice;
    do{
        printf("Do you want to (H)it or (S)tand? ");
        scanf(" %c", &choice);
        choice = tolower(choice);
    }while(choice != 'h' && choice != 's');
    return choice;
}
