/*File: main.c
 *Description: Blackjack Games
 *
 *----------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment: HW8          Date assigned:
 *Programmer: Keenen Cates Date completed:
 */

#include <stdio.h>
#include <stdlib.h>
#include "cards.h"

int main(void){
	/*Variables*/
	int num_decks, user_money = 1000, user_bet, player_score = 0, dealer_score = 0;
	shoe_t shoe;
	hand_t user_hand, dealer_hand;
	char user_action;
	/*1. Greet the user.*/
	print_greeting();
	/*2. Get number of decks in shoe (1-10).*/
	num_decks = get_decks();
	shoe = create_shoe(num_decks);
	/*3. While player still has money and hasn't quit.*/
	do{
        /*3.1. Print remaining stake and num cards left in shoe.*/
        printf("Your stake: $%d\n", user_money);
        printf("Cards left in the shoe: %d\n", cards_left(shoe));
        /*3.2. Ask user for bet(and validate.*/
        user_bet = get_user_bet(user_money);
        if(user_bet < 0){
            printf("You ended the night with $%d\n", user_money);
            free_shoe(&shoe);
            return 0;
        }

        /*3.3. Draw dealer and player hand.*/
        deal_hand(&shoe, &user_hand, &dealer_hand);
        /*3.4. Display the first card of the dealer's hand and entire player hand.*/
        printf("The dealer is showing ");
        print_card(dealer_hand.cardsInHand[0]);
        printf("\n");
        print_hand(user_hand);
        player_score = blackjack_points(user_hand);
        printf("Score = %d\n", player_score);
        /*3.5. While player's score is less than 21 and haven't stood.*/
        do{
            /*3.5.1. Ask user to stand or hit (validate input)*/
            user_action = hit_or_stand();
            if(user_action == 'h'){
                add_card_to_hand(&user_hand, draw_card(&shoe));
                print_hand(user_hand);
                player_score = blackjack_points(user_hand);
                printf("Score = %d\n", player_score);
            }
        }while((player_score < 21) && (user_action != 's'));

        dealer_score = blackjack_points(dealer_hand);
        while(dealer_score < 17){
            add_card_to_hand(&dealer_hand, draw_card(&shoe));
            dealer_score = blackjack_points(dealer_hand);
        }

        /*3.6. Determine the winner and update stake.*/
        if(player_score > 21){
            printf("You Busted. You Lose!\n");
            user_money -= user_bet;
        }
        else if(dealer_score > 21){
            printf("Dealer cards:\n");
            int i;
            for(i = 0; i < dealer_hand.numCardsInHand; i++){
                print_card(dealer_hand.cardsInHand[i]);
            }
            printf("Dealer Busts. You Win $%d!\n", user_bet*2);
            user_money += user_bet;
        }
        else if(player_score == dealer_score){
            printf("Dealer cards:\n");
            int i;
            for(i = 0; i < dealer_hand.numCardsInHand; i++){
                print_card(dealer_hand.cardsInHand[i]);
            }
            printf("Dealer ties with a score of %d\n", dealer_score);
        }
        else if(dealer_score < 22 && dealer_score > player_score){
            printf("Dealer cards:\n");
            int i;
            for(i = 0; i < dealer_hand.numCardsInHand; i++){
                print_card(dealer_hand.cardsInHand[i]);
            }
            printf("Dealer wins with a score of %d. You Lost!\n", dealer_score);
            user_money -= user_bet;
        }
        else if(player_score < 22 && dealer_score < player_score){
            printf("Dealer cards:\n");
            int i;
            for(i = 0; i < dealer_hand.numCardsInHand; i++){
                print_card(dealer_hand.cardsInHand[i]);
            }
            printf("Dealer had %d. You win $%d!\n", dealer_score, user_bet*2);
            user_money += user_bet;
        }
	}while(user_money > 0 && user_bet >= 0);
	printf("You've lost your entire stake!\n");
    free_shoe(&shoe);
	return 0;
}

