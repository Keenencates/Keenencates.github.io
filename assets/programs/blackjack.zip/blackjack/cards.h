#ifndef CARDS_H_INCLUDED
#define CARDS_H_INCLUDED

#define MAX_HAND 22

typedef struct{
    char suit;
    int value;
}card_t;

typedef struct{
    card_t *deck;
    int numDecks;
    int deckIndex;
}shoe_t;

typedef struct{
    card_t cardsInHand[MAX_HAND];
    int numCardsInHand;
}hand_t;

/*Card Functions*/
extern card_t create_card(char suit, int value);
extern void print_card(card_t card);
extern int points(card_t card);
/*Shoe Functions*/
extern shoe_t create_shoe(int numDecks);
extern card_t draw_card(shoe_t *shoe);
extern int cards_left(shoe_t shoe);
extern void reshuffle(shoe_t shoe);
extern void free_shoe(shoe_t *shoe);
/*Hand Functions*/
extern hand_t empty_hand(void);
extern void print_hand(hand_t hand);
extern void add_card_to_hand(hand_t *hand, card_t card);
extern int blackjack_points(hand_t hand);
/*Aux Functions*/
extern void deal_hand(shoe_t *shoe, hand_t *user_hand, hand_t *dealer_hand);
extern int get_user_bet(int total_money);
extern int get_decks(void);
extern void print_greeting(void);
extern char hit_or_stand(void);

#endif // CARDS_H_INCLUDED
