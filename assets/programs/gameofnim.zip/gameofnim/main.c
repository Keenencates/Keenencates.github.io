/*File: main.c
 *Description:  The game of Nim.
 *
 *----------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment: HW4          Date assigned: 02/18/2015
 *Programmer: Keenen Cates Date completed: 02/25/2015
 */

/*Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h> /*tolower*/

/*Function Prototypes*/
void printGreeting();
int userContinue();
void printScore(int compWins, int userWins);
int playNim(int startingPlayer);
void dispHeaps(int heap1, int heap2, int heap3, int playerNum);
void getMove(int heap1, int heap2, int heap3, int *numberRemoved, char *heapChoosen);

/*Main*/
int main()
{
    int playerStarting, compWins, userWins, winCond;
    compWins = 0;
    userWins = 0;
    playerStarting = 1;
    /*1. Print program banner*/
    printGreeting();

    /*2. Play Nim while user wishes to continue.*/
    do
    {
        winCond = playNim(playerStarting);
        /*2.1. Increment win count*/
        if(winCond == 0)
        {
            printf("Player 1 wins!\n");
            userWins++;
            playerStarting = 2;
        }
        if(winCond == 1)
        {
            printf("Player 2 wins!\n");
            compWins++;
            playerStarting = 1;
        }

        /*2.2. Print the current score.*/
        printScore(compWins, userWins);

    }
    while(userContinue());

    /*. Return 0.*/
    return 0;
}

/*Functions*/

/*printGreeting - prints a greeting.
Receives: N/A
Returns: N/A
*/
void printGreeting()
{
    /*1. Print program banner*/
    printf("Welcome to the Ancient Game of Nim\n");
    printf("Player 1 is you (the human)\n");
    printf("Player 2 is me (the computer)\n");
}

/*userContinue - asks user if they want to continue.
Receives: N/A
Returns: Boolean
*/
int userContinue()
{
    char response;
    /*1. Ask user if they want to continue while response is 'y' or 'n'.*/
    do
    {
        printf("\nDo you wish to play again? (y/n) ");
        scanf(" %c", &response);
        response = tolower(response);
        /*1.1. Check for input error*/
        if(response != 'y' && response != 'n')
            printf("Bad input! Try again.\n");
    }
    while(response != 'y' && response != 'n');
    /*2. Return boolean value.*/
    return response == 'y';
}

/*printScore - prints out current number of wins by the computer.
Receives: int compWins and int userWins
Returns: N/A
*/
void printScore(int compWins, int userWins)
{
    /*1. Print separator and "Current Score: "*/
    printf("\n* * * * * * * * * * *\n");
    printf("Current Score:\n");
    /*2. Print (Human) wins.*/
    printf("Player 1 (Human):    %d\n", userWins);
    /*3. Print (Computer) wins.*/
    printf("Player 2 (Computer): %d\n", compWins);
}

/*playNim - play one game of Nim with startingPlayer going first.
Receives: int startingPlayer
Returns: int winner
*/
int playNim(int startingPlayer)
{
    /*1. Initialize heap variables.*/
    int heapA, heapB, heapC;
    heapA = 5;
    heapB = 4;
    heapC = 3;
    /*2. Initialize choice variables.*/
    int numberRemoved;
    char heapChoosen;
    /*3. Initialize turn variable depending on starting player.*/
    int turn;
    if(startingPlayer == 1)
        turn = 1;
    if(startingPlayer == 2)
        turn = 2;
    /*4. Print who is first.*/
    printf("Player %d goes first this time!\n", startingPlayer);
    /*5. Play game while input is correct.*/
    do
    {
        /*5.1. If turn has a remainder when divided by 2 then player 1 goes*/
        if(turn % 2 == 1 )
        {
            /*5.1.1. Ask for user input and check for all possible errors.*/
            do
            {
                /*5.1.1.1. Display current heaps.*/
				dispHeaps(heapA, heapB, heapC, 1);
				/*5.1.1.2. Ask for input.*/
                printf("Enter the letter of the heap and number of stones to remove: ");
                scanf(" %c%d", &heapChoosen, &numberRemoved);
                heapChoosen = tolower(heapChoosen);
                if((heapChoosen != 'a' && heapChoosen != 'b'
                    && heapChoosen != 'c') || (numberRemoved <= 0) || (heapChoosen == 'a'
					&& numberRemoved > heapA) || (heapChoosen == 'b' && numberRemoved > heapB)
					|| (heapChoosen == 'c' && numberRemoved > heapC))
                    printf("Illegal move! Try again.\n");
            }
            while((heapChoosen != 'a' && heapChoosen != 'b'
                   && heapChoosen != 'c') || (numberRemoved <= 0) || (heapChoosen == 'a'
				   && numberRemoved > heapA) || (heapChoosen == 'b' && numberRemoved > heapB)
				   || (heapChoosen == 'c' && numberRemoved > heapC));
        }

        /*5.2. If turn has a remainder of 0 when divided by 2 then player 2 goes*/
        if(turn % 2 == 0)
        {
            /*5.2.1. Diplays heaps.*/
			dispHeaps(heapA, heapB, heapC, 2);
			/*5.2.2. Get computers move with getMove.*/
            getMove(heapA, heapB, heapC, &numberRemoved, &heapChoosen);
            printf("COMPUTER moves %c%d\n", heapChoosen, numberRemoved);
        }

        /*5.3. Subtract from heaps.*/
        switch(heapChoosen)
        {
        case 'a':
            heapA = heapA - numberRemoved;
            break;
        case 'b':
            heapB = heapB - numberRemoved;
            break;
        case 'c':
            heapC = heapC - numberRemoved;
            break;
        }

        /*5.4. Check to see if player has won.*/
        if(heapA == 0 && heapB == 0 && heapC == 0){
            if(turn % 2 == 1)
                return 0;
            if(turn % 2 == 0)
                return 1;
        }

        /*5.5. Increment turn counter*/
        turn++;
    }
    while(heapA != 0 || heapB != 0 || heapC != 0);
    return 0;
}

/*dispHeaps - displays current heaps.
Receives: heap1, heap2, heap3, player#
Returns: N/A
*/
void dispHeaps(int heap1, int heap2, int heap3, int playerNum)
{
    printf("\nPlayer %d\n", playerNum);
    printf("Heaps:\n");
    printf("A: %d\n", heap1);
    printf("B: %d\n", heap2);
    printf("C: %d\n", heap3);
}

/*getMove - Calculates perfect move for computer based on a winning algorithm.
Receives: int heapA, int heapB, int heapC
Returns: N/A
Passed back: char heapChoosen, int numberRemoved
*/
void getMove(int heap1, int heap2, int heap3, int *numberRemoved, char *heapChoosen)
{
    int nimNum;
    /*1. Use alg to find nimNum*/
    nimNum = heap1 ^ heap2 ^ heap3;

    /*2. If nimNum == 0; remove 1 from first available stack.*/
    if(nimNum == 0)
    {
        if(heap1 != 0)
            *heapChoosen = 'a';
        else if(heap1 == 0 && heap2 != 0)
            *heapChoosen = 'b';
        else if(heap1 == 0 && heap2 == 0 && heap3 != 0)
            *heapChoosen = 'c';
        *numberRemoved = 1;
    }
    /*3. Otherwise use alg to find pc move.*/
    else
    {
        if((heap1 ^ nimNum) < heap1)
        {
            *heapChoosen = 'a';
            *numberRemoved = heap1 - (heap1 ^ nimNum);
        }
        else if((heap2 ^ nimNum) < heap2)
        {
            *heapChoosen = 'b';
            *numberRemoved = heap2 - (heap2 ^ nimNum);
        }
        else if((heap3 ^ nimNum) < heap3)
        {
            *heapChoosen = 'c';
            *numberRemoved = heap3 - (heap3 ^ nimNum);
        }
    }
}




