/*File: main.c
 *Description: Rock, Paper, Scissors Game
 *
 *--------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment: #2            Date assigned: 01/28/2015
 *Programmer: Keenen Cates Date completed: 02/03/2015
 */

/*libraries*/
#include <stdio.h>
#include <stdlib.h>

/*function prototypes*/
void printGreeting();
void printPicks(char player, int playerNum);
char getPick(int playerNum);
int computeWinner(char player1, char player2);
char makeLowercase(char word);

/*Main*/
int main()
{
    char player1;                                   /*player 1 & 2 store pick values input by users, winner used to store winner value from function*/
    char player2;
    int winner;

    printGreeting();                                /*program banner*/

    player1 = getPick(1);                           /*use function to prompt users for picks*/
    player2 = getPick(2);

    printf("\n");

    printPicks(player1, 1);                         /*print input picks*/
    printPicks(player2, 2);

    winner = computeWinner(player1, player2);       /*compute the winner*/

    switch (winner)                                 /*winner condition switches*/
    {
    case 1:
        printf("Player 2 wins!\n");
        break;

    case 0:
        printf("Tie!\n");
        break;

    case -1:
        printf("Player 1 wins!\n");
        break;
    }
    return 0;
}

/*printGreeting: prints sample text/program banner*/
void printGreeting()
{
    printf("Welcome to the RPS Game!\n"             /*print stuff in banner*/
           "Let's play!!\n");
} /*end printGreeting*/

/*printPicks: print out what each user picks*/
void printPicks(char player, int playerNum)          /*player = player's choice: received*/
{
    switch (player)                                  /*playerNum = number of player: received*/
    {
    case 'r':
        printf("Player %d chose Rock\n", playerNum);                  /*make cases that convert player's choice into a printf statement*/
        break;
    case 's':
        printf("Player %d chose Scissors\n", playerNum);
        break;
    case 'p':
        printf("Player %d chose Paper\n", playerNum);
        break;
    default:
        printf("Player %d chose Unknown\n", playerNum);
        break;
    }
}/*end printPicks*/

/*getPick: prompts user by player number to enter R, P, or S and return character in lowercase.*/
char getPick (int playerNum)                        /*playerNum = number of player: received*/
{
    char pick;                                      /*ch = choice of player: returned*/
    char ch;
    printf("Player %d, Pick (R)ock, (P)aper, or (S)cissors: ", playerNum);              /*ask user for pick*/
    scanf (" %c", &pick);
    ch = makeLowercase(pick);
    return ch;
}/*end getPick*/

/*computeWinner: return a number that represents outcome of match. -1 player 1 wins, 1 player 2 wins, and 0 tie*/
int computeWinner(char player1, char player2)                 /*player1 & 2 players choices: received*/
{

    switch(player1)                                             /*make cases for all outcomes, return values dependent on who wins*/
    {

    case 'r':
        if (player2 == 'r')
            return  0;
        if (player2 == 'p')
            return  1;
        if (player2 == 's')
            return -1;
        else
            return -1;
        break;

    case 'p':
        if (player2 == 'r')
            return -1;
        if (player2 == 'p')
            return  0;
        if (player2 == 's')
            return  1;
        else
            return -1;
        break;


    case 's':
        if (player2 == 'r')
            return  1;
        if (player2 == 'p')
            return -1;
        if (player2 == 's')
            return  0;
        else
            return -1;
        break;

    default:
        if (player2 == 'r')
            return  1;
        if (player2 == 'p')
            return  1;
        if (player2 == 's')
            return  1;
        else
            return  0;
        break;

    }
}/*end computeWinner*/

/*Lower case converter, basically same thing as tolower*/
char makeLowercase(char word)
{
    if (word >= 'A' && word <= 'Z')         /*check if word is capital*/
    {
        return word + 'a' - 'A';            /*add distance between lower and upper case to word*/
    }
    else
    {
        return word;
    }
}/*end makeLowercase*/
