// File: sweeper.cpp 
// Driver for minesweeper game.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 04    Date assigned:  10/14/2015
// Programmer: Keenen Cates  Date completed: 10/28/2015
/*Start of Includes*/
#include <iostream>
#include <cstdlib>
#include <stdexcept>
#include "sweepergrid.h"
#include "sweepercell.h"
/*End of Includes*/

/*Start of Defines*/
//Fix this later if I can be asked.
#define TRUE true
#define FALSE false
/*End of Defines*/

using namespace std;
/*Start of Main*/
int main(int argc, char* argv[]){
	bool errorState = FALSE;
	bool gameState;
	bool firstTurn = TRUE;
	int row, col, turnNumber = 1;
	SweeperGrid testGrid;
	
	/*Check Args*/
	if (argc != 4) {
		cerr << "Usage: " << argv[0] << " ROWS COLS DENSITY" << endl;
		return 1;
	}
	
	/*Try constructing the grid*/
	SweeperGrid grid(atoi(argv[1]), atoi(argv[2]), atoi(argv[3]));
	/*Exit program if out of range*/
	if(grid.GetRows() == 0){
		cerr << "Error: Please enter a row and column that is 5 or greater and a density that is between 25 and 75" << endl;
		return 1;
	}
	
	/*print num bombs*/
	cout << "There are "<< grid.GetBombs() << " bombs in the grid.";
	
	/*main game loop*/
	/*initialize gameState*/
	gameState = grid.GameWon();
	int maxMarks = grid.GetBombs();
	int currentMarks = 0;
	while(!(gameState)){
		char userChoice;
		/*print grid*/
		cout << endl << endl;
		grid.Write(cout);
		
		/*menu*/
		do{
			cout << endl << endl << "TURN NO. " << turnNumber << endl;
			cout << "MARKS USED: " << currentMarks << '/' << maxMarks << endl;
			cout << "Enter u to uncover, m to mark, k to unmark, q to quit: ";
			cin >> userChoice;
			switch(userChoice){
			/*uncover*/
			case 'u':
				try{
					/*ask for input*/
					cout << "Enter a location (row col) to uncover: ";
					if(cin >> row >> col){
						/*uncover the first bit*/
						bool move = grid.Uncover(row, col);
						if(move){
							/*If its the first turn get rid of bomb*/
							if(!(firstTurn)){
								/*If they lose print out uncovered grid*/
								gameState = TRUE; //game flag
								for(int i = 0; i < grid.GetRows(); i++){
									for(int j = 0; j < grid.GetColumns(); j++){
										grid.Uncover(i, j);
									}
								}
								cout << endl << endl;
								grid.Write(cout);
								cout << endl << "You've uncovered a mine. Game over." << endl;
							}
							/*Move bomb if first turn is uncovering a bomb*/
							if(firstTurn){
								grid.RemoveBomb(row, col);
								bool bombPlaced = FALSE;
								for(int i = 0; i < grid.GetRows(); i++){
									for(int j = 0; j < grid.GetColumns(); j++){
										if(!((grid.At(i, j)).HasBomb()) && (i != row && j != col) && !(bombPlaced)){
											grid.PlaceBomb(i, j);
											bombPlaced = TRUE;
										}
									}
								}
							}
						}
						if(grid.GameWon()){
								cout << "You won." << endl;
								gameState = TRUE;
						}
						firstTurn = FALSE;
						turnNumber++;
					}
					else{
						cout << "Invalid input, Try again." << endl;
						cin.clear(); // clears the error state
						cin.ignore();
					}
				}
				catch(const out_of_range& re){
					cout << re.what() << "  Try again!" << endl;
				}
				errorState = FALSE;
				break;
				
			case 'm':
				try{
					cout << "Enter a location (row col) to mark: ";
					if(cin >> row >> col){
						grid.Mark(row, col);
						if(gameState == grid.GameWon()){
							cout << "You won." << endl;
						}
						firstTurn = FALSE;
						turnNumber++;
						currentMarks++;
					}
					if(currentMarks == maxMarks){
						cout << "You have reached the maximum marks. Please try unmarking a cell." << endl;
						cin.clear();
						cin.ignore();
					}
					else{
						cout << "Invalid input, Try again." << endl;
						cin.clear(); // clears the error state
						cin.ignore();
					}
				}
				catch(const out_of_range& re){
					cout << re.what() << "  Try again!" << endl;
				}
				errorState = FALSE;
				break;
				
			case 'k':
				try{
					cout << "Enter a location (row col) to unmark: ";
					if(cin >> row >> col){
						grid.Unmark(row, col);
						if(gameState == grid.GameWon()){
							cout << "You won." << endl;
						}
						firstTurn = FALSE;
						turnNumber++;
					}
					else{
						cout << "Invalid input, Try again." << endl;
						cin.clear(); // clears the error state
						cin.ignore();
					}
				}
				catch(const out_of_range& re){
					cout << re.what() << "  Try again!" << endl;
				}
				errorState = FALSE;
				break;
				
			case 'q':
				gameState = TRUE;
				errorState = FALSE;
				break;
				
			default:
				cerr << "Invalid Selection, Try Again" << endl;
				errorState = TRUE;
				break;
			}
		}while(errorState);
	}
	/*Assignment Test*/
	testGrid = grid;
	/*return 0*/
	return 0;
}
/*End of Main*/