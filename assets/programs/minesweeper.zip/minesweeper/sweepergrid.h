// File: sweepergrid.h 
// Contains functions for sweepergrid abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 04    Date assigned:  10/14/2015
// Programmer: Keenen Cates  Date completed: 10/28/2015
#ifndef GRID_H_
#define GRID_H_
/*Start of Includes*/
#include "sweepercell.h"
/*End of Includes*/
class SweeperGrid{
	/*Start of Public*/
	public:
		/*Start of Constructors*/
		/*Explicit-Value Constructor*/
		SweeperGrid(int initialRows = 5, int initialCols = 5, int density = 25);
		/*Copy Constructor*/
		SweeperGrid(const SweeperGrid& grid1);
		/*Destructor*/
		~SweeperGrid();
		/*= operator*/
		SweeperGrid& operator=(const SweeperGrid& rhs);
		/*End of Constructors*/
		
		/*Start of Mutators*/
		/*PlaceBomb*/
		void PlaceBomb(int row, int col);	
		/*RemoveBomb*/
		void RemoveBomb(int row, int col);
		/*Mark*/
		void Mark(int row, int col);
		/*Unmark*/
		void Unmark(int row, int col);
		/*Uncover*/
		bool Uncover(int row, int col);
		/*End of Mutators*/

		/*Start of Accessors*/
		/*At*/
		SweeperCell& At(int row, int col) const;
		/*GetRows*/
		int GetRows() const;
		/*GetColumns*/
		int GetColumns() const;
		/*GetBombs*/
		int GetBombs() const;
		/*GameWon*/
		bool GameWon() const;
		/*Write*/
		std::ostream& Write(std::ostream& out) const;
		/*inBounds*/
		bool inBounds(int col, int row);
		/*End of Accessors*/
	/*End of Public*/
	
	/*Start of Private*/
	private:
		int numRows, numCols, numBombs;
		SweeperCell** grid;
	/*End of Private*/
	
	/*Start of Friend Functions*/
	/*End of Friend Functions*/
};

#endif