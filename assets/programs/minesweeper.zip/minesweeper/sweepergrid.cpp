// File: sweepergrid.cpp 
// Contains functions for sweepergrid abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 04    Date assigned:  10/14/2015
// Programmer: Keenen Cates  Date completed: 10/28/2015
/*Start of Includes*/
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include "sweepergrid.h"
#include "sweepercell.h"
/*End of Includes*/

/*Start of Defines*/
//Fix this later if I can be asked.
#define TRUE true
#define FALSE false
/*End of Defines*/

/*Start of Function Definitions*/
/*Start of Constructors*/
/*Explicit-Value Constructor 
rc'd: init rows, init cols, and density
*/
SweeperGrid::SweeperGrid(int initialRows, int initialCols, int density){
	/*If initialRows < 5 or initialCols < 5 or if density is not between 25 and 75, flag grid for error*/
	if((initialRows < 5 || initialCols < 5) || !(density >= 25 && density <= 75)){
		/*Throw exception for range error*/
		//throw std::out_of_range("One or more grid parameters out of range.");
		/*No idea why, but try block doesn't allow me to declare a variable. SO, set flag for invalid SweeperGrid*/
		numRows = 0; // error flag
	}
	else{
		/*Initialize private variables*/
		numRows = initialRows;
		numCols = initialCols;
		numBombs = 0;
		
		/*Dynamically allocate grid array*/
		grid = new SweeperCell*[numRows];
		for(int i = 0; i < numRows; i++){
			grid[i] = new SweeperCell[numCols];
		}
		
		/*Place Bombs*/
		srand(time(0));
		for(int i = 0; i < numRows; i++){
			for(int j = 0; j < numCols; j++){
				if((rand() % 100 + 1) < density){
					PlaceBomb(i, j);
				}
			}
		}
	}
}
/*Copy Constructor*/
SweeperGrid::SweeperGrid(const SweeperGrid& grid1){
	numRows = grid1.GetRows(); 
	numCols = grid1.GetColumns(); 
	numBombs = grid1.GetBombs();
	
	grid = new SweeperCell*[numRows];
	for(int i = 0; i < numRows; i++){
		grid[i] = new SweeperCell[numCols];
	}
	
	for(int i = 0; i < numRows; i++){
		for(int j = 0; j < numCols; j++){
			grid[i][j] = grid1.At(i, j);
		}
	}
}
/*Destructor*/
SweeperGrid::~SweeperGrid(){
	for(int i = 0; i < numRows; i++){
		delete [] grid[i];
	}
	delete[] grid;
}
/*= operator*/
SweeperGrid& 
SweeperGrid::operator=(const SweeperGrid& rhs){
	if (this == &rhs)
		return *this;
	
	for(int i = 0; i < numRows; i++){
		delete [] grid[i];
	}
	delete [] grid;
	
	numRows = rhs.GetRows(); 
	numCols = rhs.GetColumns(); 
	numBombs = rhs.GetBombs();
	
	grid = new SweeperCell*[numRows];
	for(int i = 0; i < numRows; i++){
		grid[i] = new SweeperCell[numCols];
	}
	for(int i = 0; i < numRows; i++){
		for(int j = 0; j < numCols; j++){
			grid[i][j] = rhs.At(i, j);
		}
	}
  return *this;
}
/*End of Constructors*/

/*Start of Mutators*/
/*PlaceBomb - Places a bomb in a sweepercell at a given index
rc'd: x and y coords
*/
void 
SweeperGrid::PlaceBomb(int row, int col){
	if(!(inBounds(row, col))){
		throw std::out_of_range("Location to place bomb is not within grid bounds.");
	}
	if(grid[row][col].HasBomb()){
	}
	else{
		grid[row][col].PlaceBomb();
		numBombs++;
		/*up*/
		if(inBounds(row + 1, col)){
			grid[row + 1][col].IncrementNumAdjacent();
		}
		/*down*/
		if(inBounds(row - 1, col)){
			grid[row - 1][col].IncrementNumAdjacent();
		}
		/*left*/
		if(inBounds(row, col - 1)){
			grid[row][col - 1].IncrementNumAdjacent();
		}
		/*right*/
		if(inBounds(row, col + 1)){
			grid[row][col + 1].IncrementNumAdjacent();
		}
		/*up left*/
		if(inBounds(row + 1, col - 1)){
			grid[row + 1][col - 1].IncrementNumAdjacent();
		}
		/*up right*/
		if(inBounds(row + 1, col + 1)){
			grid[row + 1][col + 1].IncrementNumAdjacent();
		}
		/*down left*/
		if(inBounds(row - 1, col - 1)){
			grid[row - 1][col - 1].IncrementNumAdjacent();
		}
		/*down right*/
		if(inBounds(row - 1, col + 1)){
			grid[row - 1][col + 1].IncrementNumAdjacent();
		}
	}
}
/*RemoveBomb - Removes bomb at given indices
rc'd: x and y
*/
void 
SweeperGrid::RemoveBomb(int row, int col){
	if(!(inBounds(row, col))){
		throw std::out_of_range("Location to remove bomb is not within grid bounds.");
	}
	if(!(grid[row][col].HasBomb())){
	}
	else{
		grid[row][col].RemoveBomb();
		numBombs--;
		/*up*/
		if(inBounds(row + 1, col)){
			grid[row + 1][col].DecrementNumAdjacent();
		}
		/*down*/
		if(inBounds(row - 1, col)){
			grid[row - 1][col].DecrementNumAdjacent();
		}
		/*left*/
		if(inBounds(row, col - 1)){
			grid[row][col - 1].DecrementNumAdjacent();
		}
		/*right*/
		if(inBounds(row, col + 1)){
			grid[row][col + 1].DecrementNumAdjacent();
		}
		/*up left*/
		if(inBounds(row + 1, col - 1)){
			grid[row + 1][col - 1].DecrementNumAdjacent();
		}
		/*up right*/
		if(inBounds(row + 1, col + 1)){
			grid[row + 1][col + 1].DecrementNumAdjacent();
		}
		/*down left*/
		if(inBounds(row - 1, col - 1)){
			grid[row - 1][col - 1].DecrementNumAdjacent();
		}
		/*down right*/
		if(inBounds(row - 1, col + 1)){
			grid[row - 1][col + 1].DecrementNumAdjacent();
		}
	}
}
/*Mark - Marks cell at given indices
rc'd: x and y
*/
void 
SweeperGrid::Mark(int row, int col){
	if(!(inBounds(row, col))){
		throw std::out_of_range("Location to mark is not within grid bounds.");
	}
	else{
		grid[row][col].Mark();
		if(grid[row][col].HasBomb()){
			numBombs--;
		}
	}
}
/*Unmark - Unmarks cell at given indices
rc'd: x and y*/
void 
SweeperGrid::Unmark(int row, int col){
	if(!(inBounds(row, col))){
		throw std::out_of_range("Location to unmark is not within grid bounds.");
	}
	else{
		grid[row][col].Unmark();
		if(grid[row][col].HasBomb()){
			numBombs++;
		}
	}	
}
/*Uncover - Uncovers cell at given indices
rc'd: x and y*/
bool 
SweeperGrid::Uncover(int row, int col){
	if(!(inBounds(row, col))){
		throw std::out_of_range("Location to uncover is not within grid bounds.");
	}
	else{
		if(!(grid[row][col].IsCovered())){
			//do nothing
			return FALSE;
		}
		grid[row][col].Uncover();
		if(grid[row][col].HasBomb()){
			return TRUE;
		}
		else{
			/*Auto-uncover zeroes - EXTRA CREDIT*/
			/*up*/
			if(inBounds(row + 1, col) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row + 1][col].IsCovered() && !(grid[row + 1][col].HasBomb())){
					Uncover(row + 1, col);
				}
			}
			/*down*/
			if(inBounds(row - 1, col) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row - 1][col].IsCovered() && !(grid[row - 1][col].HasBomb())){
					Uncover(row - 1, col);
				}
			}
			/*right*/
			if(inBounds(row, col + 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row][col + 1].IsCovered() && !(grid[row][col + 1].HasBomb())){
					Uncover(row, col + 1);
				}
			}
			/*left*/
			if(inBounds(row, col - 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row][col - 1].IsCovered() && !(grid[row][col - 1].HasBomb())){
					Uncover(row, col - 1);
				}
			}
			/*up left*/
			if(inBounds(row + 1, col - 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row + 1][col - 1].IsCovered() && !(grid[row + 1][col - 1].HasBomb())){
					Uncover(row + 1, col - 1);
				}
			}
			/*up right*/
			if(inBounds(row + 1, col + 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row + 1][col + 1].IsCovered() && !(grid[row + 1][col + 1].HasBomb())){
				Uncover(row + 1, row + 1);
				}
			}
			/*down left*/
			if(inBounds(row - 1, col - 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row - 1][col - 1].IsCovered() && !(grid[row - 1][col - 1].HasBomb())){
					Uncover(row - 1, col - 1);
				}
			}
			/*down right*/
			if(inBounds(row - 1, col + 1) && grid[row][col].GetNumAdjacent() == 0){
				if(grid[row - 1][col + 1].IsCovered() && !(grid[row - 1][col + 1].HasBomb())){
					Uncover(row - 1, col + 1);
				}
			}
			/*Return FALSE*/
			return FALSE;
		}
	}
}
/*End of Mutators*/

/*Start of Accessors*/
/*At - returns reference to a cell at given indices
rc'd: x and y
*/
SweeperCell& 
SweeperGrid::At(int row, int col) const{
	return grid[row][col];
}
/*GetRows - returns number of rows*/
int 
SweeperGrid::GetRows() const{
	return numRows;
}
/*GetColumns - returns number of columns*/
int 
SweeperGrid::GetColumns() const{
	return numCols;
}
/*GetBombs - returns number of bombs*/
int 
SweeperGrid::GetBombs() const{
	return numBombs;
}
/*GameWon - checks if the game is won, and returns a bool*/
bool 
SweeperGrid::GameWon() const{
	if(numBombs == 0){
		return TRUE;
	}
	else
		return FALSE;
}
/*Write - out puts grid to an ostream*/
std::ostream& 
SweeperGrid::Write(std::ostream& out) const{
	for(int i = 0; i < numRows; i++){
		for(int j = 0; j < numCols; j++){
			out << "  " << grid[i][j];
		}
		out << std::endl;
	}
	return out;
}
/*inBounds - returns whether or not indices are in bounds of the grid
rc'd: x and y
*/
bool 
SweeperGrid::inBounds(int row, int col){
	if((row >= numRows || row < 0 ) || (col >= numCols || col < 0 )){
		return FALSE;
	}
	else
		return TRUE;
}
/*End of Accessors*/

/*Start of Friend Functions*/
/*End of Friend Functions*/
/*End of Function Definitions*/