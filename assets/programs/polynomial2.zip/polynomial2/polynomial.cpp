// File: polynomial.cpp
// Polynomial function definitions.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015

#include <iostream>
#include <vector>
#include <cmath>
#include "polynomial.h"
#include "term.h"

/*Start of Constructors*/
/*Default Constructor - Constructs a polynomial*/
Polynomial::Polynomial(){
	/*Header Node*/
	head = new Polynomial::Node();
	head->next = NULL;
}
	
/*Explicit-Value Constructor - Constructs a polynomial
RC'd: Vector of coefficients that are doubles, and a integer vector of exponents
*/
Polynomial::Polynomial(std::vector<double> initCoefficients, std::vector<int> initExponents){
	/*Header Node*/
	head = new Polynomial::Node();
	head->next = NULL;
	
	/*temp Node*/
	Polynomial::Node* temp = head; 
	
	for(unsigned int i = 0; i < initCoefficients.size(); i++){
		/*1. Make a new node && set header + temp*/
		Polynomial::Node* newNode = new Polynomial::Node;
		newNode->next = NULL;
		
		/*2. Get Data*/
		newNode->data.coefficient = initCoefficients.at(i);
		newNode->data.exponent = initExponents.at(i);
		
		/*3. set temp node*/
		temp->next = newNode;
		temp = newNode;
	}
}
/*Constructs a polynomial with a pointer to a node - This is to make life easier when trying to make a polynomial out of a list*/
Polynomial::Polynomial(Node* listHead){
	/*Header Node*/
	head = listHead;
}
/*Copy Constructor*/
Polynomial::Polynomial(const Polynomial& polynomial1){
	/*Header Node*/
	head = new Polynomial::Node();
	head->next = NULL;
	/*temp Node*/
	Polynomial::Node* temp = head; 
	
	for(Polynomial::Node* i = polynomial1.head->next; i != NULL; i = i->next){
		/*1. Make a new node && set header + temp*/
		Polynomial::Node* newNode = new Polynomial::Node();
		newNode->next = NULL;

		/*2. Get Data*/
		newNode->data.coefficient = i->data.coefficient;
		newNode->data.exponent = i->data.exponent;

		/*3. set temp node*/
		temp->next = newNode;
		temp = newNode;
	}
}
/*Destructor*/
Polynomial::~Polynomial(){
	Node* temp = head;
	while(head != NULL){
		head = temp->next;
		delete temp;
		temp = head;
	}
	delete head;
}
/*= operator*/
Polynomial& 
Polynomial::operator=(const Polynomial& polynomial1){
	/*Destroy everything in current head*/
	Node* temp = head;
	while(head != NULL){
		head = temp->next;
		delete temp;
		temp = head;
	}
	delete head;

	/*Header Node*/
	head = new Polynomial::Node;
	head->next = NULL;
	/*temp Node*/
	temp = head; 
	
	for(Polynomial::Node* i = polynomial1.head->next; i != NULL; i = i->next){
		/*1. Make a new node && set header + temp*/
		Polynomial::Node* newNode = new Polynomial::Node;
		newNode->next = NULL;
		/*2. Get Data*/
		newNode->data.coefficient = i->data.coefficient;
		newNode->data.exponent = i->data.exponent;
		/*3. set temp node*/
		temp->next = newNode;
		temp = newNode;
	}
	return *this;
}
/*End of Constructors*/
		
/*Start of Mutators*/
/*End of Mutators*/

/*Start of Accessors*/
int 
Polynomial::Degree() const{
	if(head->next != NULL){
		return head->next->data.exponent;
	}
	else
		return 0;
}
double 
Polynomial::Evaluate(double x) const{
	double sum = 0.0;
	if(head->next != NULL){
		for(Polynomial::Node* i = head->next; i != 0; i = i->next){
			sum += pow(x, i->data.exponent) * (i->data.coefficient);
		}
	}
	else{}
	return sum;
}

/*Derivative - Returns a polynomial that is the derivative of an object*/
Polynomial 
Polynomial::Derivative() const{
	/*Header Node*/
	Polynomial::Node* newhead = new Polynomial::Node;
	newhead->next = NULL;
	if(head->next != NULL){
		/*temp Node*/
		Polynomial::Node* temp = newhead; 
	
		for(Polynomial::Node* i = head->next; i != 0; i = i->next){
			/*1. Make a new node && set header + temp*/
			Polynomial::Node* newNode = new Polynomial::Node;
			newNode->next = NULL;
			/*2. Get Data*/
			newNode->data.coefficient = (i->data.coefficient) * (i->data.exponent);
			newNode->data.exponent = i->data.exponent - 1;
			/*3. set temp node*/
			temp->next = newNode;
			temp = newNode;
		}
	return Polynomial(newhead);
	}
	return Polynomial(newhead);
}
/*End of Accessors*/
/*End of Public*/
	
/*Start of Friend Functions*/
/*+ operator - returns a polynomial that is the sum of two rc'd polynomials*/
Polynomial operator+(const Polynomial& polynomial1, const Polynomial& polynomial2){
	/*Header Node*/
	Polynomial::Node* newhead = new Polynomial::Node;
	newhead->next = NULL;
	/*temp Node*/
	Polynomial::Node* temp = newhead;
	
	Polynomial::Node* i = polynomial1.head->next;
	Polynomial::Node* j = polynomial2.head->next;
	while(i != NULL || j != NULL){
		/*1. Make a new node && set header + temp*/
		Polynomial::Node* newNode = new Polynomial::Node;
		newNode->next = NULL;
		/*2. Get Data*/
		/*j is NULL*/
		if(i != NULL && j == NULL){
			newNode->data.coefficient = i->data.coefficient;
			newNode->data.exponent = i->data.exponent;
			i = i->next;
		}
		/*i is NULL*/
		else if(i == NULL && j != NULL){
			newNode->data.coefficient = j->data.coefficient;
			newNode->data.exponent = j->data.exponent;
			j = j->next;
		}
		else{
			/*p1 >  p2*/
			if(i->data.exponent > j->data.exponent){
				newNode->data.coefficient = i->data.coefficient;
				newNode->data.exponent = i->data.exponent;
				i = i->next;
			}
			/*p1 <  p2*/
			else if(i->data.exponent < j->data.exponent){
				newNode->data.coefficient = j->data.coefficient;
				newNode->data.exponent = j->data.exponent;
				j = j->next;
			}
			/*p1 == p2*/
			else if(i->data.exponent == j->data.exponent){
				newNode->data.coefficient = i->data.coefficient + j->data.coefficient;
				newNode->data.exponent = i->data.exponent;
				i = i->next;
				j = j->next;
			}
		}
		/*3. set temp node*/
		temp->next = newNode;
		temp = newNode;
	}
	return Polynomial(newhead);
}
/* * operator - returns a polynomial that is the product of two rc'd polynomials*/
Polynomial operator*(const Polynomial& polynomial1, const Polynomial& polynomial2){
	Polynomial result;
	for(Polynomial::Node* i = polynomial1.head->next; i != NULL; i = i->next){
		/*Header Node*/
		Polynomial::Node* newhead = new Polynomial::Node;
		newhead->next = NULL;
		/*temp Node*/
		Polynomial::Node* temp = newhead;
		for(Polynomial::Node* j = polynomial2.head->next; j != NULL; j = j->next){
			/*1. Make a new node && set header + temp*/
			Polynomial::Node* newNode = new Polynomial::Node;
			newNode->next = NULL;
			/*2. Get Data*/
			newNode->data.coefficient = (i->data.coefficient) * (j->data.coefficient);
			newNode->data.exponent = i->data.exponent + j->data.exponent;
			/*3. set temp node*/
			temp->next = newNode;
			temp = newNode;
		}
		result = (result + (Polynomial(newhead)));
	}
	return result;
}
/*<< operator - overloaded operator to output a polynomial
rt'd: a stream of type ostream&
rc'd: a polynomial and an ostream
*/
std::ostream& operator<<(std::ostream& out, Polynomial polynomial1){
	if(polynomial1.head->next != NULL){
		bool firstTerm = true;
		for(Polynomial::Node* i = polynomial1.head->next; i != NULL; i = i->next){
			if(i->data.coefficient >= 1.0 && !firstTerm){
				out << '+';
			}
			if(i->data.coefficient != 0){
				out << i->data;
			}
			else{
				if(firstTerm && i->next != NULL){
					out << 0;
				}
				if(firstTerm && i->next == NULL && i->data.coefficient == 0){
					out << 0;
				}
			}
			firstTerm = false;
		}
	}		
	else{
		out << 0;
	}
	return out;
}
/*>> operator - overloaded operator to input a polynomial
rt'd: a stream of type istream&
rc'd: a reference to a polynomial and an istream
*/
std::istream& operator>>(std::istream& in, Polynomial& Polynomial1){
	/*Buffers*/
	double dBuff;
	int iBuff;
	char ch;
	Polynomial::Node* newhead = new Polynomial::Node;
	Polynomial::Node* temp = newhead;
	while(in >> ch){
		in.putback(ch);
		/*Case where + is read in - eat plus*/
		if(in.peek() == '+'){
			in >> ch; /*eat the +*/
		}
		/*Cases where - is read in first*/
		else if(in.peek() == '-'){
			in >> ch; /*eat the -*/
			/*-x^b*/
			if(in.peek() == 'x'){
				in >> ch; /*eat the x*/
				Polynomial::Node* newNode = new Polynomial::Node;
				newNode->next = NULL;
				newNode->data.coefficient = -1;
				/*check exponent*/
				if(in.peek() == '^'){
					in >> ch; /*eat the ^*/
					in >> iBuff; /*read in exponent*/
					newNode->data.exponent = iBuff;
				}
				else{
					newNode->data.exponent = 1;
				}
				temp->next = newNode;
				temp = newNode;
			}
			else{
				in >> dBuff;
				Polynomial::Node* newNode = new Polynomial::Node;
				newNode->next = NULL;
				newNode->data.coefficient = -(dBuff);
				/*check for x*/
				if(in.peek() == 'x'){
					in >> ch; /*eat the x*/
					/*check for exponent*/
					if(in.peek() == '^'){
						in >> ch; /*eat the ^*/
						in >> iBuff; /*read in the exponent*/
						newNode->data.exponent = iBuff;
					}
					else{
						newNode->data.exponent = 1;
					}
				}
				/*if no x*/
				else{
					newNode->data.exponent = 0;
				}
				temp->next = newNode;
				temp = newNode;
			}
		}
		/*x^b*/
		else if(in.peek() == 'x'){
			in >> ch; /*eat the x*/
			Polynomial::Node* newNode = new Polynomial::Node;
			newNode->next = NULL;
			newNode->data.coefficient = 1;
			/*check exponent*/
			if(in.peek() == '^'){
				in >> ch; /*eat the ^*/
				in >> iBuff; /*read in exponent*/
				newNode->data.exponent = iBuff;
			}
			else{
				newNode->data.exponent = 1;
			}
			temp->next = newNode;
			temp = newNode;
		}
		/*ax^b*/
		else{
			in >> dBuff;
			Polynomial::Node* newNode = new Polynomial::Node;
			newNode->next = NULL;
			newNode->data.coefficient = (dBuff);
			/*check for x*/
			if(in.peek() == 'x'){
				in >> ch; /*eat the x*/
				/*check for exponent*/
				if(in.peek() == '^'){
					in >> ch; /*eat the ^*/
					in >> iBuff; /*read in the exponent*/
					newNode->data.exponent = iBuff;
				}
				else{
					newNode->data.exponent = 1;
				}
			}
			/*if no x*/
			else{
				newNode->data.exponent = 0;
			}
			temp->next = newNode;
			temp = newNode;
		}
	}
	Polynomial1 = Polynomial(newhead);
	return in;
}
/*End of Friend Functions*/
