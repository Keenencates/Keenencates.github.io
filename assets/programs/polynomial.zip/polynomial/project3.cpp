// File: project3.cpp
// Driver for polynomial abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 03    Date assigned:  09/28/2015
// Programmer: Keenen Cates  Date completed: 10/09/2015
/*Start of Includes*/
#include <iostream>
#include <vector>
#include <sstream>
#include "polynomial.h"
/*End of Includes*/
using namespace std;
/*Start of Function Prototypes*/
/*End of Function Prototypes*/
/*Start of Main*/
int main(){
	vector<double> coef;
	vector<int> exp;
 	Polynomial p1;
	for(int i = 2; i > -1 ; i--)
		coef.push_back(i);
	for(int i = 2; i > -1 ; i--)
		exp.push_back(i);
	Polynomial p2(coef, exp);
	istringstream polynomialIN;
	
	cout << "Default Constructor Test: " << endl;
	cout << p1 << endl << endl;
	
	cout << "Explicit Constructor Test: " << endl;
	cout << p2 << endl << endl;
	
	//cout << "Derivative Test: " << endl;
	//cout << p2.Derivative() << endl << endl;
	
	cout << "Evaluate Test: " << endl;
	cout << p2.Evaluate(2) << endl << endl;
	
	//cout << "Input Test" << endl;
	//cin >> p1;
	//cout << p1 << endl << endl;
	
	cout << "Addition Test" << endl;
	cout << p2 + p2 << endl << endl;
	
	cout << "Multiplication Test" << endl;
	cout << p2 * p1 << endl << endl;
	return 0;
}
/*End of Main*/
/*Start of Function Definitions*/
/*End of Function Definitions*/