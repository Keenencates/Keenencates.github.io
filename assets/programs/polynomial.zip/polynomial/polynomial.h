// File: polynomial.h 
// Contains functions for polynomial abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 03    Date assigned:  09/28/2015
// Programmer: Keenen Cates  Date completed: 10/09/2015
#ifndef CLASS_H
#define CLASS_H

#include <iostream>
#include <vector>

class Polynomial{
	/*Start of Public*/
	public:
		/*Start of Constructors*/
		Polynomial();
		Polynomial(std::vector<double> initialCoefficients, std::vector<int> initialExponents);
		/*End of Constructors*/
		/*Start of Mutators*/
		/*End of Mutators*/
		/*Start of Accessors*/
		int Degree() const ;
		double Evaluate(double x) const;
		Polynomial Derivative() const;
		double operator[](int index) const;
		double at(int index) const;
		/*End of Accessors*/
	/*End of Public*/
	/*Start of Private*/
	private:
		std::vector<double> coefficients;
	/*End of Private*/
	/*Start of Friend Functions*/
	friend Polynomial operator+(Polynomial polynomial1, Polynomial polynomial2);
	friend Polynomial operator*(Polynomial polynomial1, Polynomial polynomial2);
	friend std::ostream& operator<<(std::ostream& out, Polynomial polynomial1);
	friend std::istream& operator>>(std::istream& input, Polynomial& Polynomial1);

	/*End of Friend Functions*/
};

int findLargestDegree(int a, int b);

#endif