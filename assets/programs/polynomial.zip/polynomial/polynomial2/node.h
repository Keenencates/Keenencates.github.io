// File: node.h
// Node abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015
#ifndef NODE_H_
#define NODE_H_
template <typename T>
class Node{
	/*Start of Public*/
	public:
		/*Data Attributes*/
		<T> data;
		Node* next;
		/*End of Data*/
		/*Start of Mutators*/
		/*push_back*/
		void push_back(Node* node, <T> data);
		/*End of Mutators*/
	/*End of Public*/
};

#endif