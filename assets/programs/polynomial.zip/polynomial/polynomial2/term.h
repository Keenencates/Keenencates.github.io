// File: polynomial.h
// Polynomial function prototypes.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015
#ifndef TERM_H_
#define TERM_H_
#include <iostream>
class Term{
	/*Start of Public*/
	public:
		/*Start of Constructors*/
		/*Explicit-Value Constructor*/
		Term(double initCoefficient = 0.0, int initExponent = 0);
		
		/*Data Attributes*/
		double coefficient;
		int exponent;
		/*End of Constructors*/
	/*End of Public*/
	
	/*Start of Friend Functions*/
	friend bool operator==(const Term& term1, const Term& term2);
	friend std::ostream& operator<<(std::ostream& out, const Term& term1);
	/*End of Friend Functions*/
};

#endif