// File: term.cpp
// term function definitions.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015
/*Start of Includes*/
#include <cmath>
#include "term.h"
/*End of Includes*/
/*Start of Constructors*/
/*Explicit-Value Constructor*/
Term::Term(double initCoefficient, int initExponent){
	coefficient = initCoefficient;
	exponent = initExponent;
}
/*End of Constructors*/

/*Start of Friend Functions*/
bool operator==(const Term& term1, const Term& term2){
	if(term1.coefficient == term2.coefficient && term1.exponent == term2.coefficient){
		return true;
	}
	else
		return false;
}
std::ostream& operator<<(std::ostream& out, const Term& term1){
	if(term1.coefficient < 0.0){
		out << '-';
	}
	if(fabs(term1.coefficient) > 0.0){
		if(fabs(term1.coefficient) != 1 || (term1.exponent == 0))
			out << fabs(term1.coefficient);
		if((term1.exponent > 0) && (fabs(term1.coefficient) != 0)){
			out << 'x';
		}
	}
	if(term1.exponent > 1){
		out << '^' << term1.exponent;
	}
	// else if(term1.exponent == 0){
		// out << term1.coefficient;
	// }
	return out;
}
/*End of Friend Functions*/