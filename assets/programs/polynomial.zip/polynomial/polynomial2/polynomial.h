// File: polynomial.h
// Polynomial function prototypes.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015
#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_
/*Start of Includes*/
#include <iostream>
#include <vector>
#include "term.h"
/*End of Includes*/
class Polynomial{
	private:
		struct Node {
			Term data;
			Node * next;
		};
	/*Start of Public*/
	public:
		/*Start of Constructors*/
		/*Default Constructor*/
		Polynomial();
		/*Explicit-Value Constructor*/
		Polynomial(std::vector<double> initCoefficients, std::vector<int> initExponents);
		Polynomial(Node* list);
		/*Copy Constructor*/
		Polynomial(const Polynomial& Polynomial1);
		/*Destructor*/
		~Polynomial();
		/*= operator*/
		Polynomial& operator=(const Polynomial& polynomial1);
		/*End of Constructors*/
		
		/*Start of Mutators*/
		/*End of Mutators*/

		/*Start of Accessors*/
		int Degree() const;
		double Evaluate(double x) const;
		Polynomial Derivative() const;
		/*End of Accessors*/
	/*End of Public*/
	
	/*Start of Private*/
	private:
		Node* head;
		//Node* newhead; //for cleanup
	/*End of Private*/
	
	/*Start of Friend Functions*/
	friend Polynomial operator+(Polynomial polynomial1, Polynomial polynomial2);
	friend Polynomial operator*(Polynomial polynomial1, Polynomial polynomial2);
	friend std::ostream& operator<<(std::ostream& out, Polynomial polynomial1);
	friend std::istream& operator>>(std::istream& input, Polynomial& Polynomial1);
	/*End of Friend Functions*/
};

#endif