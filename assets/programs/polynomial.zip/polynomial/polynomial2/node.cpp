// File: term.cpp
// Node function definitions.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 05    Date assigned:  10/28/2015
// Programmer: Keenen Cates  Date completed: 11/06/2015
/*Start of Includes*/
#include <iostream>
/*End of Includes*/

template <typename T>
void push_back(Node* node, <T> data) {
  Node* new_node = new Node;
  new_node->data = data;

  tail->next = new_node;
  new_node->prev = tail;
  new_node->next = l;
  l->prev = new_node;
}