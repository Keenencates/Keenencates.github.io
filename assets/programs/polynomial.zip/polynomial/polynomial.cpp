// File: polynomial.cpp
// Function definitions for polynomial abstract data type.
//
// --------------------------------------------------------
// Class:      CS 215	     Instructor:     Dr. Don Roberts	
// Assignment: Project 03    Date assigned:  09/28/2015
// Programmer: Keenen Cates  Date completed: 10/09/2015
/*Start of Includes*/
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include "polynomial.h"
/*End of Includes*/
/*Start of Constructors*/
/*Default Constructor
*/
Polynomial::Polynomial(){
	coefficients.resize(1);
	coefficients.at(0) = 0;
}
/*Explicit-Value Constructor*/
Polynomial::Polynomial(std::vector<double> initialCoefficients = std::vector<double> initialCoefficients(0), std::vector<int> initialExponents){
	if(initialCoefficients.empty()||(initialExponents.empty()))
		coefficients.push_back(0);
	else{
		coefficients.resize(initialExponents.at(0) + 1);
		for(int i = 0; i < initialExponents.at(0) + 1; i++)
			coefficients.at(i) = 0;
		for(int i = 0; i < initialExponents.size(); i++){
			coefficients.at(initialExponents.at(initialExponents.size() - i - 1)) = initialCoefficients.at(initialExponents.size() - i - 1);
		}
	}
}
/*End of Constructors*/
/*Start of Accessors*/
/*Degree - returns the highest exponent of the polynomial*/
int 
Polynomial::Degree() const{
	return coefficients.size() - 1;
}
double
Polynomial::Evaluate(double x) const{
	int value = 0;
	for(int i = 0; i <= Degree(); i++){
		value += (coefficients.at(i) * pow(x, i));
	}
	return value;
}
Polynomial
Polynomial::Derivative() const{
	std::vector<int> initialExponents;
	std::vector<double> initialCoefficients;
	for(int i = 1; i < coefficients.size(); i++){
		initialCoefficients.push_back(coefficients.at(coefficients.size() - i) * (coefficients.size() - i));
		initialExponents.push_back(coefficients.size() - i - 1); 
	}
	return Polynomial(initialCoefficients, initialExponents);
}
double 
Polynomial::operator[](int index) const{
	return coefficients[index];
}
double 
Polynomial::at(int index) const{
	return coefficients.at(index);
}
/*End of Accessors*/
/*Start of Mutators*/
/*End of Mutators*/
/*Start of Friend Functions*/
Polynomial operator+(Polynomial polynomial1, Polynomial polynomial2){
	std::vector<int> initialExponents;
	std::vector<double> initialCoefficients;
	int largestDegree = findLargestDegree(polynomial1.Degree(), polynomial2.Degree());
	for(int i = 0; i <= largestDegree; i++){
		double num1, num2;
		num1 = polynomial1[largestDegree - i];
		num2 = polynomial2[largestDegree - i];
		if((largestDegree - i) > polynomial1.Degree())
			num1 = 0;
		if((largestDegree - i) > polynomial2.Degree())
			num2 = 0;
		initialCoefficients.push_back(num1 + num2);
		initialExponents.push_back(largestDegree - i);
		std::vector<double> zeroVector(initialCoefficients.size(), 0);
		if(initialCoefficients == zeroVector){
			initialExponents.clear();
		}
	}
	return Polynomial(initialCoefficients, initialExponents);
}
Polynomial operator*(Polynomial polynomial1, Polynomial polynomial2){
	std::vector<int> initialExponents;
	std::vector<double> initialCoefficients;
	Polynomial poly;
	if((polynomial1.Degree() == 0 || polynomial2.Degree()  == 0) && (polynomial1.at(0) == 0 || polynomial2.at(0)  == 0))
		return poly;
	for(int i = 0; i <= polynomial1.Degree(); i++){
		for(int j = 0; j <= polynomial2.Degree(); j++){
			double num1;
			num1 = polynomial1.at(polynomial1.Degree() - i) * polynomial2.at(polynomial2.Degree() - j);
			initialCoefficients.push_back(num1);
			int exponent = (polynomial1.Degree() - i) + (polynomial2.Degree() -j);
			initialExponents.push_back(exponent);
		}
		std::vector<double> zeroVector(initialCoefficients.size(), 0);
		if(initialCoefficients == zeroVector){
			initialExponents.clear();
		}
		poly = poly + Polynomial(initialCoefficients, initialExponents);
		initialCoefficients.clear();
		initialExponents.clear();
	}
 	return poly;
}
std::ostream& operator<<(std::ostream& out, Polynomial polynomial1){
	if(polynomial1.Degree() != 0){
		/*Cases for initial term*/
		if(polynomial1.at(polynomial1.Degree()) == 0.0){
		}
		if(polynomial1.at(polynomial1.Degree()) == 1.0){
			if(polynomial1.Degree() > 0){
				out << "x";
				if(polynomial1.Degree() > 1){
					out << "^" << polynomial1.Degree();
				}	
			}

		}
		if(polynomial1.at(polynomial1.Degree()) == -1.0){
			out << '-';
			if(polynomial1.Degree() > 0){
				out << "x";
				if(polynomial1.Degree() > 1){
					out << "^" << polynomial1.Degree();
				}	
			}

		}
		if(polynomial1.at(polynomial1.Degree()) < -1.0){
			out << '-' << fabs(polynomial1.at(polynomial1.Degree()));
			if(polynomial1.Degree() > 0){
				out << "x";
				if(polynomial1.Degree() > 1){
					out << "^" << polynomial1.Degree();
				}	
			}

		}
		if(polynomial1.at(polynomial1.Degree()) > 1.0){
			out << (polynomial1.at(polynomial1.Degree()));
			if(polynomial1.Degree() > 0){
				out << "x";
				if(polynomial1.Degree() > 1){
					out << "^" << polynomial1.Degree();
				}	
			}

		}
	}
	for(int i = 1; i < polynomial1.Degree(); i++){
		/*Inbetween cases*/
		if(polynomial1.at(polynomial1.Degree() - i) == 0.0){
			/*do nothing*/
		}
		if(polynomial1.at(polynomial1.Degree() - i) == 1.0){
			out << "+x";
			if(polynomial1.Degree() - i > 1){
				out << "^" << polynomial1.Degree() - i;
			}
		}
		if(polynomial1.at(polynomial1.Degree() - i) == -1.0){
			out << "-x";
			if(polynomial1.Degree() - i > 1){
				out << "^" << polynomial1.Degree() - i;
			}
		}
		if((polynomial1.at(polynomial1.Degree() - i) < -1.0)){
			out << '-' << fabs(polynomial1.at(polynomial1.Degree() - i)) << 'x';
			if(polynomial1.Degree() - i > 1){
				out << "^" << polynomial1.Degree() - i;
			}			
		}
		if((polynomial1.at(polynomial1.Degree() - i) > 1.0)){
			out << '+' << (polynomial1.at(polynomial1.Degree() - i)) << 'x'; 
			if(polynomial1.Degree() - i > 1){
				out << "^" << polynomial1.Degree() - i;
			}
		}
	}
	/*Cases for constant/last term.*/
	if(polynomial1.at(0) == 0){
		if(polynomial1.Degree() == 0)
			out << 0;
		}
		/*do nothing*/
	else{
		if((polynomial1.at(0) < 0) && (polynomial1.Degree() != 0))
			out << '-' << fabs(polynomial1.at(0));
		if((polynomial1.at(0) > 0) && (polynomial1.Degree() != 0))
			out << '+' << polynomial1.at(0);
		if(polynomial1.Degree() == 0)
			out << polynomial1.at(0);
	}
	return out;
}

std::istream& operator>>(std::istream& in, Polynomial& polynomial1){
	std::vector<double> initialCoefficients;
	std::vector<int> initialExponents;
	/*Buffers*/
	double dBuff;
	int iBuff;
	char ch;
	while(in >> ch){
		in.putback(ch);
		/*Case where + is read in - eat plus*/
		if(in.peek() == '+'){
			in >> ch; /*eat the +*/
		}
		/*Cases where - is read in first*/
		if(in.peek() == '-'){
			in >> ch; /*eat the -*/
			/*-x^b*/
			if(in.peek() == 'x'){
				in >> ch; /*eat the x*/
				initialCoefficients.push_back(-1);
				/*check exponent*/
				if(in.peek() == '^'){
					in >> ch; /*eat the ^*/
					in >> iBuff; /*read in exponent*/
					initialExponents.push_back(iBuff);
				}
				else{
					initialExponents.push_back(1);
				}
			}
			else{
				in >> dBuff;
				initialCoefficients.push_back(-(dBuff));
				/*check for x*/
				if(in.peek() == 'x'){
					in >> ch; /*eat the x*/
					/*check for exponent*/
					if(in.peek() == '^'){
						in >> ch; /*eat the ^*/
						in >> iBuff; /*read in the exponent*/
						initialExponents.push_back(iBuff);
					}
					else{
						initialExponents.push_back(1);
					}
				}
				/*if no x*/
				else{
					initialExponents.push_back(0);
				}
			}
		}
		/*x^b*/
		if(in.peek() == 'x'){
			in >> ch; /*eat the x*/
			initialCoefficients.push_back(1);
			/*check exponent*/
			if(in.peek() == '^'){
				in >> ch; /*eat the ^*/
				in >> iBuff; /*read in exponent*/
				initialExponents.push_back(iBuff);
			}
			else{
				initialExponents.push_back(1);
			}
		}
		/*ax^b*/
		else{
			in >> dBuff;
			initialCoefficients.push_back((dBuff));
			/*check for x*/
			if(in.peek() == 'x'){
				in >> ch; /*eat the x*/
				/*check for exponent*/
				if(in.peek() == '^'){
					in >> ch; /*eat the ^*/
					in >> iBuff; /*read in the exponent*/
					initialExponents.push_back(iBuff);
				}
				else{
					initialExponents.push_back(1);
				}
			}
			/*if no x*/
			else{
				initialExponents.push_back(0);
			}
		}
	}
	polynomial1 = Polynomial(initialCoefficients, initialExponents);
	return in;
}
int findLargestDegree(int a, int b){
	int largestDegree;
	if(a < b)
		largestDegree = b;
	if(a > b)
		largestDegree = a;
	if(a == b)
		largestDegree = a;
	return largestDegree;
}
/*End of Friend Functions*/