#include <vector>
#include <iostream>
#include <iomanip>
#include <algorithm>

using namespace std;

void selection_sort(vector<int>& v);
void insertion_sort(vector<int>& v);
void shell_sort(vector<int>& v);
void merge(const vector<int>& v1, const vector<int>& v2, vector<int>& result);
void merge_sort(vector<int>& v, int start, int end);
void quicksort(vector<int>& v, int start, int end);
int part(vector<int>& v, int start, int end);

void heapsort(vector<int> &v);
void reheapify(vector<int>& v, int violator_index, int end_of_heap);
void make_heap(vector<int> &v);
int left_child(int i);
int right_child(int i);

int comp_count;

int main() {
  vector<int> v;
  int size = 25; 
  //DATA CHART
  //header
  cout << left << setw(12) << "       Size " << left << setw(12) << "  selection " << left << setw(12) << "     insert " 
       << left << setw(12) << "      shell " << left << setw(12) << "      merge " << left << setw(12) << "   heapsort "
	   << left << setw(12) << "  quicksort " << endl;
  for(int i = 0; i < 8; i++){
    size = size * 2;
	for(int i=0; i<size; i++) {
	  v.push_back(rand() % size);
	}
	
	cout << right << setw(11) << size << " ";

    comp_count = 0;
    auto v1(v);
    selection_sort(v1);
    cout << right << setw(11) << comp_count << " ";

    auto v2(v);
    comp_count = 0;
    insertion_sort(v2);
    cout << right << setw(11) << comp_count << " ";

    auto v3(v);
    comp_count = 0;
    shell_sort(v3);
    cout << right << setw(11) << comp_count << " ";

    auto v4(v);
    comp_count = 0;
    merge_sort(v4, 0, size);
    cout << right << setw(11) << comp_count << " ";
	
    auto v5(v);
    comp_count = 0;
    heapsort(v5);
    cout << right << setw(11) << comp_count << " ";
	
    auto v6(v);
    comp_count = 0;
    quicksort(v6, 0, size);
    cout << right << setw(11) << comp_count << " ";
	
	cout << endl;
  }
  return 0;
}

void selection_sort(vector<int>& v) {
  for (int i = 0; i<v.size(); i++) {
    int min_index = i;
    for (int j=i+1; j<v.size(); j++) {
      comp_count++;
      if (v[j] < v[min_index]) {  // if smaller
	min_index = j;            // update min_index
      }
    }
    // min_index - index of smallest element
    swap(v[i], v[min_index]);
  }
}

void insertion_sort(vector<int>& v) {
  for (int i=1; i<v.size(); i++) {
    // assume all v[i-1] and less are sorted already
    int j=i;
    comp_count++;
    while (j>0 && v[j-1] > v[j]) {
      comp_count++;
      swap(v[j-1], v[j]);
      j--;
    }
  }
}

void shell_sort(vector<int>& v) {
  int gap = v.size() / 2;

  while (gap > 0) {
    for (int start=0; start<gap; start++) {
      for (int i=start; i<v.size(); i += gap) {
	// assume all v[i-1] and less are sorted already
	int j=i;
	comp_count++;
	while (j >= gap && v[j-gap] > v[j]) {
	  comp_count++;
	  swap(v[j-gap], v[j]);
	  j--;
	}
      }
    }
    if (gap == 2)     // make sure that the final time gap is 1
      gap = 1;
    else
      gap = gap / 2.2;
  }
}

void merge_sort(vector<int>& v, int start, int end) {
  if (end - start <= 1) {
    return;
  }

  int middle = (end + start) / 2;

  merge_sort(v, start, middle);
  merge_sort(v, middle, end);

  vector<int> v1;
  vector<int> v2;

  for(int i=start; i<middle; i++) {
    v1.push_back(v[i]);
  }

  for(int i=middle; i<end; i++) {
    v2.push_back(v[i]);
  }
  
  vector<int> temp;

  merge(v1, v2, temp);

  for (int i=0; i<temp.size(); i++) {
    v[start+i] = temp[i];
  }
  
  
}


void merge(const vector<int>& v1, const vector<int>& v2, vector<int>& result) {
  int i1;
  int i2;

  i1 = 0;
  i2 = 0;

  while (i1 < v1.size() && i2 < v2.size()) {  // while something on both piles
    // pick smaller
    if (v1[i1] < v2[i2]) {
      result.push_back(v1[i1]);
      i1++;
	  comp_count++;
    } else {
      result.push_back(v2[i2]);
      i2++;
	  comp_count++;
    }
  }
  //
  while (i1 < v1.size()) {
    result.push_back(v1[i1]);
    i1++;
  }
  while (i2 < v2.size()) {
    result.push_back(v2[i2]);
    i2++;
  }
}

// quicosrt - sorts using the quicksort algorithm

void quicksort(vector<int>& v, int start, int end) {
  if (end - start <= 1)  // base case
    return;
  int middle = part(v, start, end);
  quicksort(v, start, middle);
  quicksort(v, middle+1, end);
}

// partitions the vector using the first element as the pivot
// return: the final index of the pivot

int part(vector<int>& v, int start, int end) {
  int pivot = v[start];
  int up = start + 1;     
  int down = end - 1;
  do {
    while (up < down && pivot >= v[up]) {
      ++up;
	  comp_count++;
    }
    while ( pivot < v[down] ) {
      --down;
	  comp_count++;
    }
    if (up < down) {
      swap(v[up], v[down]);
	  comp_count++;
    }
  } while (up<down); // until the indexes cross

  swap(v[start], v[down]);
  return down;
}

// heapsort - sorts using a heap. Worst case O(n lg n)

void heapsort(vector<int> &v) {
  make_heap(v);
  int unsorted = v.size();  // just past the unsorted part (end of heap)

  while(unsorted > 1) {
    unsorted--;
    swap(v[0], v[unsorted]);
    reheapify(v, 0, unsorted);  // fix heap with violation at v[0]
	comp_count++;
  }
}

// make_heap - converts an array into a heap
void make_heap(vector<int> &v) {
  for (int i=v.size()/2; i>=0; i--) {
    reheapify(v, i, v.size());
  }
}

// reheapify - fixes heap violation at root

void reheapify(vector<int>& v, int violator_index, int end_of_heap) {
  int current_offender = violator_index;

  while(left_child(current_offender) < end_of_heap ) {
    int biggest_index = current_offender;
    int child = left_child(current_offender);

    if (v[child] > v[current_offender])
      biggest_index = child;
	comp_count++;
    if (child+1 < end_of_heap && v[child+1] > v[biggest_index])
      biggest_index = child + 1;
    	comp_count++; comp_count++;
    if (biggest_index == current_offender)
      return;    // we're done - the heap is fixed
    else {
      swap(v[current_offender], v[biggest_index]);
      current_offender = biggest_index;
    }
  }
}

int left_child(int i) {
  return 2 * i + 1;
}

int right_child(int i) {
  return 2 * i + 2;
}
