/*File: main.c
 *Description: Reverse Guessing Game
 *
 *----------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment: #3           Date assigned: 02/04/2015
 *Programmer: Keenen Cates Date completed:
 */

/*Libraries*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>  /*tolower*/

/*Function Prototypes*/
void printGreeting(int min, int max, int guesses);
void printResults(int compWins, int userWins);
int userContinue();
char promptUser(int guess);
int playGame(int min, int max, int guesses);


/*Main*/
int main(){
	int min, max, guesses, winner, compWins, userWins;
	min = 1;
    max = 1000;
	guesses = 5;
	/*1. Print greeting*/
	printGreeting(min, max, guesses);

	/*2. Initialize counter variable to 0*/
	compWins = 0;
	userWins = 0;

	/*3. In a loop, play game, increment win count
		 and games played until user wishes to quit*/
	do{

		winner = playGame(min, max, guesses);

		switch(winner)
		{
        case 1:
            compWins++;
            break;
        case 0:
            userWins++;
            break;
		}

	} while (userContinue());
	/*4. Print results and ending message*/
		printResults(compWins, userWins);
	/*5. Return 0*/
	return 0;
}

/*printGreeting - print banner, range, and guesses*/
void printGreeting(int min, int max, int guesses){
	printf("Welcome to the (reverse) guessing game.\n");
	printf("Choose a number between %d and %d inclusive\n", min, max);
	printf("and I will try to guess it in %d or fewer tries\n\n", guesses);
}

/*printResults - display win count and exit message*/
void printResults(int compWins, int userWins){
	printf("I won %d game(s).\n", compWins);
	printf("You won %d game(s).\n", userWins);
	printf("Thank you for playing!\n");
}

int userContinue(){
	char response;

	do{
		printf("\nDo you wish to continue (y/n)? ");
		scanf(" %c", &response);
		response = tolower(response);
		if(response != 'y' && response != 'n')
			printf("Bad Input. Try again.\n");
	} while(response != 'y' && response != 'n');

	return response == 'y';
}

char promptUser(int guess){
	char response;
    printf("My guess is %d.\n", guess);
	do{
		printf("Is my guess too (H)igh, too (L)ow, or (E)qual to your number? ");
		scanf(" %c", &response);
		response = tolower(response);
		if(response != 'h' && response != 'l' && response != 'e')
			printf("Bad Input. Try again.\n");
	} while(response != 'h' && response != 'l' && response != 'e');
	return response;
}

int playGame(int min, int max, int guesses){
	int maxGuess, minGuess, winCondition, usedGuesses, currentGuess;
	char response;
/*1. Initialize Variables*/
	maxGuess = max;
	minGuess = min;
	usedGuesses = 0;
	winCondition = 0;
/*2. While pc has guesses and hasn't won*/
	do
	{
	    /*a. Compute guess as average of high and low*/
	    currentGuess = (maxGuess + minGuess) / 2;
	    /*b. Get response from user with promptUser*/
	    response = promptUser(currentGuess);
	    /*c. switch statement to determine win*/
	    switch(response)
	    {
        case 'h':
            maxGuess = currentGuess - 1;
            usedGuesses++;
            break;

        case 'l':
            minGuess = currentGuess + 1;
            usedGuesses++;
            break;

        case 'e':
            winCondition = 1;
            usedGuesses++;
            guesses = usedGuesses;
            break;
	    }
	} while (usedGuesses != guesses);
/*4. If winCondition = 1 print "I won!" and usedGuesses, otherwise print "You won!"*/
    switch(winCondition)
    {
    case 1:
        printf("I win! It took me %d guess(es).\n", usedGuesses);
        break;

    case 0:
        printf("You win!\n");
        break;
    }
/*5. Return winCondition*/
    return winCondition;
}
