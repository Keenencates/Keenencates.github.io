
public class MainGame {
	
	//Did not change syntax to North, South, East, West. 
	//I don't feel as if it makes sense in the context of the game Although the game does support it
	//by writing the file correct i.e naming the exit "West" and having the description detail
	//Where it is
	
	//Did clear up the syntax in the help command
	
	public static void main(String args[]){
		GameEngine engine = new GameEngine();
		engine.printIntro();
		engine.getPlayerRoom().printShort();
		engine.parseInput();
		System.out.print("Good-Bye!");
	}
}
