public class GameActor extends GameObjectHolder{
	
	GameRoom currentRoom;
	boolean pickupable, legality;
	
	public GameActor(String name, String description, GameRoom startingRoom){
		super(name, description);
		currentRoom = startingRoom;
		currentRoom.addObject(this);
		pickupable = false;
		legality = true;
	}
	
	public GameActor(String name, String description, GameRoom startingRoom, boolean pickupable, boolean legality){
		super(name, description);
		currentRoom = startingRoom;
		currentRoom.addObject(this);
		this.pickupable = pickupable;
		this.legality = legality;
	}
	

	public void moveTo(GameRoom room){
		currentRoom.removeObject(this);
		currentRoom = room;
		currentRoom.addObject(this);
	}
	
	public GameRoom getCurrentRoom(){
		return currentRoom;
	}
	
	public boolean isInRoom(GameRoom r){
		return r.getName().equals(currentRoom.name);
	}
	
	public void makePickupable(){
		pickupable = true;
	}
}
