import java.util.HashSet;
import java.util.Set;

//An object that holds GameObjects
public class GameObjectHolder extends GameObject{
	
	Set<GameObject> holder;
	
	public GameObjectHolder(){
		super();
	}

	public GameObjectHolder(String name, String description){
		super(name, description);
		holder = new HashSet<>();
	}

	public GameObjectHolder(String name, String description, Set<GameObject> holder){
		super(name, description);
		this.holder = holder;
	}
	
	public void addObject(GameObject object){
		holder.add(object);
	}
	
	public void removeObject(GameObject object){
		holder.remove(object);
	}
	
	public String getObjects(){
		String oString = "";
		for(GameObject each: holder){
			oString += each.getName() + " ";
		}
		return oString;
	}
	
	public boolean contains(GameObject o){
		return holder.contains(o);
	}
	
}
