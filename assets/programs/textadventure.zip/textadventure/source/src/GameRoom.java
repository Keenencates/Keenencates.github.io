import java.util.HashSet;

public class GameRoom extends GameObjectHolder{
	
	String short_description;
	
	public GameRoom(){
		super();
		short_description = "default_game_room";
	}
	
	public GameRoom(String name, String description, String short_description){
		super(name, description, new HashSet<>());
		this.short_description = short_description;
	}
	
	public void printShort(){
		System.out.println(short_description);
	}
	
	public String getShort(){
		return short_description;
	}
	
}
