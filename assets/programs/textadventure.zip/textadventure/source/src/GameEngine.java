import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class GameEngine{
	HashMap<String, GameActor> actorMap;
	HashMap<String, GameRoom> map;
	Vector<GameActor> shiplist;
	
	GameActor currentShip = null;
	
	String intro;
	
	boolean shipParked = false;
	
	int citations = 0;
	
	public GameEngine(){
		getGame();
	}
	
	public void getGame(){
		actorMap = new HashMap<String, GameActor>();
		map = new HashMap<String, GameRoom>();
		shiplist = new Vector<>();
		getIntro();
		readRooms();
		readActors();
		populateShipList();
	}
	
	public void printIntro(){
		System.out.println(intro + "\n");
	}
	
	public void getIntro(){
		try{
			
			BufferedReader br = new BufferedReader(new FileReader("src/game.txt"));
			String line;
			
			while((line = br.readLine()) != null){
				
				/*----PARSE INTRO----*/
				if(line.equals("INTRO{")){
					intro = "";
					while(!(line = br.readLine()).equals("}INTRO;")){
						intro = intro + "\n" + line;
					}
				}
			}
			br.close();
		}catch(IOException e){
			System.out.println(e);
		}
	}
	
	public GameRoom getRoomInfo(String s){
		String name = "", description = "", short_description = ""; 
			
		try{
			BufferedReader br = new BufferedReader(new FileReader("src/game.txt"));
			String line;
				
			while((line = br.readLine()) != null){
					
				if(line.equals(s + "{")){
					while(!((line = br.readLine()).equals("}" + s + ";"))){
						name = line;
						line = br.readLine();
						description = line;
						line = br.readLine();
						short_description = line;
					}
				}
				
			}
			br.close();
				
		}catch(IOException e){
			System.out.println(e);
		}
		return new GameRoom(name, description, short_description);
	}
	
	public GameActor getActorInfo(String s){
		
		String name = "", description = "";
		boolean pickupable = false;
		boolean legality = true;
		GameRoom startingRoom = new GameRoom();
		
		try{
			BufferedReader br = new BufferedReader(new FileReader("src/game.txt"));
			String line;
			
			while((line = br.readLine()) != null){
				
				if(line.equals(s + "{")){
					
					while(!((line = br.readLine()).equals("}" + s + ";"))){
						name = line;
						line = br.readLine();
						description = line;
						line = br.readLine();
						startingRoom = map.get(line);
						line = br.readLine();
						if(line.equals("pickupable")){
							pickupable = true;
						}
						line = br.readLine();
						if(line.equals("illegal")){
							legality = false;
						}
					}
				
				}
			
			}
			br.close();
			
		}catch(IOException e){
			System.out.println(e);
		}
		
		return new GameActor(name, description, startingRoom, pickupable, legality);
	}
	
	public void readActors(){
		try{
			BufferedReader br = new BufferedReader(new FileReader("src/game.txt"));
			String line;
			
			while((line = br.readLine()) != null){
				
				if(line.equals("ALLACTORS{")){
					
					while(!((line = br.readLine()).equals("}ALLACTORS;"))){
						actorMap.put(line, getActorInfo(line));
					}
				
				}
			
			}
			br.close();
			
		}catch(IOException e){
			System.out.println(e);
		}
	}
	
	public void readRooms(){
		try{
			BufferedReader br = new BufferedReader(new FileReader("src/game.txt"));
			String line;
			
			while((line = br.readLine()) != null){
				
				if(line.equals("ALLROOMS{")){
					
					while(!((line = br.readLine()).equals("}ALLROOMS;"))){
						map.put(line, getRoomInfo(line));
					}
				
				}
			
			}
			br.close();
			
		}catch(IOException e){
			System.out.println(e);
		}
		
	}
	
	public void parseInput(){
		Scanner scanner = new Scanner(System.in);
		boolean userCont = true;
		
		while(userCont){
			String s = scanner.nextLine();
			String input;
			
			try{
				
				if(s.contains("examine")){
					
					input = s.substring("examine".length() + 1);
					
					if((isSameRoom(input) || isPlayerHolding(input)) && !isShip(input) ){
						getActor(input).printDescription();
					}else{
						throw new InputMismatchException();
					}
					
				}else if(s.contains("pickup")){
					
					input = s.substring("pickup".length() + 1);
					
					if(isSameRoom(input) && getActor(input).pickupable){
						playerPickup(input);
						System.out.println("I picked up the " + input + ". ");
					}else{
						throw new InputMismatchException();
					}
					
				}else if(s.contains("drop")){
					
					input = s.substring("drop".length() + 1);
					
					if(isPlayerHolding(input)){
						playerDrop(input);
						System.out.println("I dropped the " + input + ". ");
					}else{
						throw new InputMismatchException();
					}
					
				}else if(s.contains("goto")){
					
					input = s.substring("goto".length() + 1);
					
					if(isSameRoom("door to the " + input)){
						getRoom(input).printShort();
						movePlayer(input);
					}else{
						throw new InputMismatchException();
					}
					
				}else if(s.contains("scan")){
					
					input = s.substring("scan".length() + 1);
					
					if(isSameRoom("Ship " + input) && isPlayerHolding("scanner")){
						getActor("Ship " + input).printDescription();
					}else{
						throw new InputMismatchException();
					}
					
				}else if(s.equals("accept ship")){
					if(!currentShip.legality){
						removeShipFromDock(currentShip.getName());
						System.out.println("Your superiors have reviewed your work and have given you a citation for recent breach of protocol.");
						citations++;
					}
					
					else if(currentShip == null){
						System.out.println("Accept what ship? Have to land one first");
					}
					
					else{
						removeShipFromDock(currentShip.getName());
					}
					
				}else if(s.equals("decline ship")){
					if(currentShip.legality){
						removeShipFromDock(currentShip.getName());
						System.out.println("Your superiors have reviewed your work and have given you a citation for recent breach of protocol.");
						citations ++;
					}
					
					else if(currentShip == null){
						System.out.println("Decline what ship? Have to land one first");
					}
					
					else{
						removeShipFromDock(currentShip.getName());
					}
					
				}else if(s.equals("use terminal")){
					if(isSameRoom("terminal")){
						spawnShip(randomShip());
					}else{
						throw new InputMismatchException();
					}
				}else if(s.equals("inventory")){
					System.out.println("Your inventory contains: " + getPlayer().getObjects());
				}else if(s.equals("look")){
					printExtendedDescription();
				}else if(s.equals("help")){
					System.out.println("In order to interact with the game world, try typing something such as \"look\"." + "\n" + "If you see something interesting try interacting with examine 'x' or pickup 'x'." + "\n" +
										"If you want to go to another room try looking, and if you see an exit such as, 'door to Hangar', try \"goto Hangar\"." + "\n" + 
										"If you want to decline a ship, say decline ship. Similiarly, for accepting a ship, say accept ship\n"
										+ " If you want to scan a ship type scan SHIPNAME  with appropriate capitalization.");
				}else if(s.equals("quit")){
					
					userCont = false;
					
				}else if(!s.isEmpty()){
					System.out.println(s);
					throw new InputMismatchException();
				}if(shiplist.isEmpty()){
					System.out.println("You've finished your work for today. Head home and take a rest. This is the end of the game so far TO DO: implement ship class, implement random components of ships, "
							+ "implement day cycles, implement pay, and on...");
				}if(citations == 3){
					System.out.println("You've failed to perform at an acceptable effeciency. Your human overlords have powered you down forever... ");
					userCont = false;
				}
			}catch(InputMismatchException e){
				System.out.println("Sorry, I don't understand what you mean.");
			}
		}
		scanner.close();
	}
	
	public void removeShipFromDock(String s){
		String ship = getActor(s).getName().substring("ship".length() + 1);
		System.out.println("The " + ship + " has done its buisness within its right to do so and taken off.");
		getActor(s).currentRoom.removeObject(getActor(s));
		for(int i = 0; i < shiplist.size(); i++){
			if(shiplist.get(i).getName().equals(currentShip.getName())){
				shiplist.remove(i);
			}
		}
		currentShip = null;
	}
	
	public GameActor randomShip(){
		
		int i = new Random().nextInt(shiplist.size());
		currentShip = shiplist.get(i);
		return shiplist.get(i);
		
	}
	
	public void populateShipList(){
		
		for(GameObject each: getRoom("Hangar").holder){
			
			if(each.getName().contains("Ship")){
				
				shiplist.add(getActor(each.getName()));
				
			}
			
		}
	}
	
	public void spawnShip(GameActor ship){
		if(!shipParked){
			String s = ship.getName().substring("ship".length() + 1);
			System.out.println("The " + s + " has landed in your dock for inspection.");
		}else{
			System.out.println("You can't hail another ship while one is already in your docking bay.");
		}
	}
	
	public boolean isShip(String s){
		return actorMap.get(s).getName().contains("Ship");
	}
	
	public boolean isPlayerHolding(String s){
		return getPlayer().contains(getActor(s));
	}
	
	public void movePlayer(String s){
		getPlayer().moveTo(getRoom(s));
	}
	
	public void playerPickup(String s){
		GameActor o = actorMap.get(s);
		if(o.pickupable){
			o.getCurrentRoom().removeObject(o);
			getPlayer().addObject(o);
		}else{
			System.out.println("I can't pick that up.");
		}
	}
	
	public void playerDrop(String s){
		GameActor o = actorMap.get(s);
		getPlayer().removeObject(o);
		getPlayer().getCurrentRoom().addObject(o);
	}
	
	public void printExtendedDescription(){
		String oString = "";
		oString += getPlayerRoom().getDescription() + " ";
		for(GameObject each: getPlayerRoom().holder){
			if(!each.getName().equals(getPlayer().getName()) && !isShip(each.getName())){
				oString += "There is a(n) " + each.getName() + ". ";
			}
		}
		System.out.println(oString);
	}
	
	public boolean isSameRoom(String s){
		return getPlayerRoom().contains(actorMap.get(s));
	}
	
	public GameActor getActor(String s){
		return actorMap.get(s);
	}
	
	public GameActor getPlayer(){
		return getActor("PLAYER");
	}
	
	public GameRoom getRoom(String s){
		return map.get(s);
	}
	
	public GameRoom getPlayerRoom(){
		return getActor("PLAYER").getCurrentRoom();
	}
}
