//import java.util.HashMap;

public class GameObject{
	String name;
	String description;
	
	//HashMap<String, GameEvent> triggers;
	
	public GameObject(){
		this("default_object", "This is a default_object");
	}
	
	public GameObject(String name){
		this(name, "Default description");
	}
	
	public GameObject(String name, String description){
		this.name = name;
		this.description = description;
	}
	
	public String getName(){
		return name;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void printName(){
		System.out.println(name);
	}
	
	public void printDescription(){
		System.out.println(description);
	}
}

