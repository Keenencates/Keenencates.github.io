# ENGR/CS 101 statistical computations
import math 

def FindMax(List):
    InstantaneousMax = List[0]
    for Item in List[1:]:
        if Item >InstantaneousMax:
            InstantaneousMax = Item
    return InstantaneousMax

def FindMin(List):
    InstantaneousMin = List[0]
    for Item in List[1:]:
        if Item <InstantaneousMin:
            InstantaneousMin = Item
    return InstantaneousMin

def ComputeRange(List):
    return FindMax(List)-FindMin(List)

def ComputeMean(List):
    Total = 0.0
    n = len(List)
    for i in range(n):
        Total = Total + List[i]
    Mean = Total/n
    return Mean

def ComputeMedian(List):
    ListCopy = List[:]
    ListCopy.sort()
    n = len(List)
    MidIdx = n/2
    if n%2 == 0: #even num of ele
        Median = ListCopy[MidIdx] + ListCopy[MidIdx - 1]/2.0
    else: #odd num of ele
        Median = ListCopy[MidIdx]
    return Median
def ComputeMode(List):
    Dict = {}
    for Items in List:
        if Items in Dict:
            Dict[Items] = Dict[Items] + 1
        else:
            Dict[Items] = 1
    MaxValue = FindMax(Dict.values())
    ModeList = []
    for item in Dict:
        if Dict[Items] == MaxValue:
            ModeList.append(Items)
    return ModeList
def ComputeStdDev(List):
    Mean = ComputeMean(List)
    y = len(List)
    for x in range(y):
        nsofar = 0
        nsofar = nsofar + (List[x] - Mean)**2
    StdDev = math.sqrt((1/(float(y)-1))*(nsofar))
    return StdDev
    
def getChoice():
    print "1. Range "
    print "2. Mean  "
    print "3. Median"
    print "4. Mode"
    print "5. Standard Deviation"
    print "q. Quit"
    Choice = raw_input("\nEnter your choice... ")
    return Choice
        
def main():
    # Ask the user for a file name and open it for reading
    inputFileName = raw_input('Enter the name of the input file: ')
    inputFile = open(inputFileName, 'r')

    # create an empty list
    Items = []

    # for each line in the input file
    for line in inputFile:
        number = int(line)
        Items.append(number)
        
    inputFile.close()
    Choice = getChoice()
    while Choice != "q":
        for Choice in range(5)
            Functions = ["Range", "Mean", "Median", "Mode", "Standard Deviation"]
            Answers = [ComputeRange(Items), ComputeMean(Items), ComputeMedian(Items), ComputeMode(Items), ComputeStdDev(Items)]
            print ("The", Functions[int(Choice)-1], "of the values is... ", Answers[int(Choice)-1])
            Choice = getChoice()


