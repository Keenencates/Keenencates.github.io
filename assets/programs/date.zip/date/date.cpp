// File: date.cpp
// Function Definitions for abstract data type: "date".
//
// --------------------------------------------------------------
// Class: CS 215             Instructor:     Dr. Don Roberts
// Assignment: Project 02    Date assigned:  9/16/2015
// Programmer: Keenen Cates  Date completed: 9/25/2015
#include <iostream>
#include <sstream>
#include <string>
#include <stdexcept>
#include "date.h"

#define MAX_MONTHS 12
#define MAX_WEEK_DAYS 7
#define MAX_DAYS_YEAR 365
#define MAX_DAYS_LEAP_YEAR 366 

Date::Date(){
	_months = 1; 
	_days = 1; 
	_years = 2000;
	_totalDays = _days;
}
Date::Date(int initMonth, int initDay, int initYear){
	/*Exceptions*/
	/*Months must be 1 to 12.*/
	if(initMonth < 1 || initMonth > 12)
		throw std::out_of_range("Month must be between 1 and 12.");
	/*Certain months have 30 or 31 days, depending on the month; February has 28 or 29 days depending on if the year is a leap year.*/
	if(((initMonth == 1)||(initMonth == 3)||(initMonth == 5)||(initMonth == 7)||(initMonth == 8)||(initMonth == 10)||(initMonth == 12)) && ((initDay < 1) || (initDay > 31)))
		throw std::out_of_range("For months January, March, May, July, August, October, and December, the day must be between 1 and 31.");
	if(((initMonth == 4)||(initMonth == 6)||(initMonth == 9)||(initMonth == 11)) && ((initDay < 1) || (initDay > 30)))
		throw std::out_of_range("For months April, June, September, and November, the day must be between 1 and 30.");
	if((isLeapYear(initYear)) && ((initDay < 1) || (initDay > 29)))
		throw std::out_of_range("On a leap year, the day for February must be between 1 and 29.");
	if((!(isLeapYear(initYear))) && ((initDay < 1) || (initDay > 28)))
		throw std::out_of_range("On a year that is not a leap year, the day for February must be between 1 and 28.");
	/*Years must be greater than 0.*/
	if(initYear < 0)
		throw std::out_of_range("The year must be greater than 0.");
	_months = initMonth;
	_days = initDay;
	_years = initYear;
	_totalDays = calcTotalDays(_months, _days, _years);
}

int
Date::GetMonth()const{
	return _months;
}

int
Date::GetDay()const{
	return _days;
}

int
Date::GetYear()const{
	return _years;
}

std::string
Date::StringName()const{
	std::string months[MAX_MONTHS] = {"January", "February", "March", "April", "May", "June",
			                          "July", "August", "September", "October", "November", 
			                          "December"};
	std::ostringstream buffer;
	buffer << months[_months - 1] << " " << _days << ", " << _years;
	return buffer.str();
}

std::string
Date::DayOfWeek()const{
	std::string weekDay[MAX_WEEK_DAYS] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", 
					                      "Friday", "Saturday"};
	/*Week Day Algorithm (as described by assignment paper)*/
	/*a*/
//	int a = (_months - 2) % MAX_MONTHS;
//	if(a < 1)
//		a += MAX_MONTHS;
	/*b*/
//	int b = _days;
	
	/*c*/
//	int c = _years % 100;
	
	/*d*/
//	int d = _years / 1000;

	/*w*/
//	int w = ((13 * a) - 1) / (5);

	/*x*/
//	int x = c / 4;

	/*y*/
//	int y = d / 4;

	/*z*/
//	int z = w + x + y + b + c - (2 * d);

	/*r*/
//	int r = z % 7;
//	if(r < MAX_WEEK_DAYS)
//		r += MAX_WEEK_DAYS;
	int r = _totalDays % 7;
	/*End of Week Day Algorithim*/
	/*return week day*/
	return weekDay[r]; 
	
}

bool operator==(const Date& date1, const Date& date2){
	return date1._totalDays == date2._totalDays;
}
bool operator<(const Date& date1, const Date& date2){
	return date1._totalDays < date2._totalDays;
}
bool operator>(const Date& date1, const Date& date2){
	return date1._totalDays > date2._totalDays;
}
bool operator<=(const Date& date1, const Date& date2){
	return date1._totalDays <= date2._totalDays;
}
bool operator>=(const Date& date1, const Date& date2){
	return date1._totalDays >= date2._totalDays;
}
bool operator!=(const Date& date1, const Date& date2){
	return date1._totalDays != date2._totalDays;
}
std::istream& operator>>(std::istream& input, Date& date1){
	int years = 0;
	int months = 0;
	int days = 0;
	input >> months;
	if(input.peek() == '/'){
		input.ignore();
		input >> days;
		if(input.peek() == '/'){
			input.ignore();
			input >> years;
		}
	}
	date1 = Date(months, days, years);
	return input;
}

std::ostream& operator<<(std::ostream& output, const Date& date1){
	output << date1.GetMonth() << "/" << date1.GetDay() << "/" << date1.GetYear();
	return output;
}

bool isLeapYear(int year){
	if(((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
		return true;
	else
		return false;
}

int calcTotalDays(int months, int days, int years){
	int totalDays = days;
	for(int i = 1; i < years; i++){
		if(isLeapYear(i))
			totalDays += MAX_DAYS_LEAP_YEAR;
		else
			totalDays += MAX_DAYS_YEAR;
	}
	for(int i = 1; i < months; i++){
			if((i == 1)||(i == 3)||(i == 5)||(i == 7)||(i == 8)||(i == 10)||(i == 12))
				totalDays += 31;
			else if((i == 4)||(i == 6)||(i == 9)||(i == 11))
				totalDays += 30;
			else
				if(isLeapYear(years))
					totalDays += 29;
				else
					totalDays += 28;
	}
	return totalDays;
}
