// File: datedriver.cpp
// Tests the "date" class.
//
// --------------------------------------------------------------
// Class: CS 215             Instructor:     Dr. Don Roberts
// Assignment: Project 02    Date assigned:  9/16/2015
// Programmer: Keenen Cates  Date completed: 9/25/2015

#include <iostream>
#include <string>
#include <stdexcept>
#include "date.h"

using namespace std;

void dateCheck(Date date1, int months, int days, int years);

int main(){
	/*Constructor Test*/
	Date example1;
	Date example2(2, 29, 1996);
	Date example3(9, 24, 2015);
	
	dateCheck(example1, 1, 1, 1);
	dateCheck(example2, 2, 29, 1996);
	dateCheck(example3, 9, 24, 2015);
	
	/*getMonths, getDays, and getYears test*/
	Date example4(example2.GetMonth(), example2.GetDay(), example2.GetYear());
	dateCheck(example4, 2, 29, 1996);
	
	/*stringName test*/
	string testDate = "February 29, 1996";
	cout << example2.StringName() << endl;
	if(testDate == example2.StringName())
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*dayOfWeek test*/
	string testDay = "Thursday";
	if(testDay == example2.DayOfWeek())
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*Operator tests*/
	/*==*/
	if(example2 == example2)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*<*/
	
	if(example1 < example2)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*>*/
	
	if(example2 > example1)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*<=*/
	
	if(example1 <= example2)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*>=*/
	
	if(example2 >= example1)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	/*!=*/
	
	if(example1 != example2)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
	
	cout << example1 << endl;
	cout << example2 << endl;
	cout << example3 << endl;
	cout << example4 << endl;
	
	int userCont = 1;
	while(userCont == 1){
		try{
			cout << "Enter a date: ";
			cin >> example1;
			cout << example1 << endl;
		}
		catch(const out_of_range& e){
			cout << "Bad date: " << e.what() << endl;
			string destroy;
			getline(cin, destroy); /*destroys bad input*/
		}
		cout << "Do you wish to continue(yes = 1, no = 0)? ";
		cin >> userCont; 
	}
	
	return 0;
}

void dateCheck(Date date1, int months, int days, int years){
	if(date1.GetYear() == years && date1.GetMonth() == months && date1.GetDay() == days)
		cout << "PASS" << endl;
	else
		cerr << "FAIL" << endl;
}
