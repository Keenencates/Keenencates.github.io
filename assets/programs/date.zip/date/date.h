// File: date.h
// Function Prototypes for abstract data type: "date".
//
// --------------------------------------------------------------
// Class: CS 215             Instructor:     Dr. Don Roberts
// Assignment: Project 02    Date assigned:  9/16/2015
// Programmer: Keenen Cates  Date completed: 9/25/2015
#ifndef DATE_H
#define DATE_H

#include <iostream>
#include <string>

class Date{
	/*Start of public*/
	public:
		/*Constructors*/
		Date();
		Date(int initMonth, int initDay, int initYear);
		/*Mutators*/
		/*Accessors*/
		int GetMonth()const;
		int GetDay()const;
		int GetYear()const;
		std::string StringName()const;
		std::string DayOfWeek()const;
	/*End of public*/
	/*Start of private*/
	private:
		int _months, _days, _years, _totalDays;
	/*End of private*/
	/*Friend Functions*/
	friend bool operator==(const Date& date1, const Date& date2);
	friend bool operator<(const Date& date1, const Date& date2);
	friend bool operator>(const Date& date1, const Date& date2);
	friend bool operator<=(const Date& date1, const Date& date2);
	friend bool operator>=(const Date& date1, const Date& date2);
	friend bool operator!=(const Date& date1, const Date& date2);
	friend std::istream& operator>>(std::istream& input, Date& date1);
	friend std::ostream& operator<<(std::ostream& output, const Date& date1);
	/*End of friend functions*/ 
};

bool isLeapYear(int year);
int calcTotalDays(int months, int days, int years);

#endif
