/*File: main.c
 *Description: Transform
 *
 *----------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment:              Date assigned:
 *Programmer: Keenen Cates Date completed:
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAXEXTENSION 10
#define MAXSTRING 100
#define ROWMAX 500
#define COLMAX 500

typedef struct{
    int red, blue, green;
} pixelT;

/*Function Prototypes*/
void printGreeting(void);
int checkFile(const char filename[], FILE *file, char fileType);
void getFiles (FILE **in, FILE **out);
void writeImage(FILE *out, pixelT image[][COLMAX], int cols, int rows);
void printFileHeader(FILE *out, int maxColor, int cols, int rows);
void readImage(FILE *in, pixelT image[][COLMAX], int *cols, int *rows, int *maxColor );
void transposeImage(pixelT image[][COLMAX], pixelT rotatedImage[][COLMAX], int cols, int rows);
void processFile(FILE *in, FILE *out);

int main(void){
    FILE *inputFile, *outputFile;
    /*1. Greet the user.*/
    printGreeting;
    /*2. Get them files.*/
    getFiles(&inputFile, &outputFile);
    /*3. Process the file.*/
    processFile(inputFile, outputFile);
    /*4. Close files.*/
    fclose(inputFile);
    fclose(outputFile);
    /*5. Return 0.*/
    return 0;
}

/*printGreeting - prints the program banner.*/
void printGreeting(void){
    printf("PPM Image Rotator\n");
}

/*getFiles - opens input and output files.
Rec'd: input file, output file
P'back: input, output
*/
void getFiles (FILE **in, FILE **out){
    char filename[FILENAME_MAX];
    int fileCheckerIN, fileCheckerOUT;
    /*Open in*/
    do{
        printf ("Enter the name of a PPM file: ");
        scanf ("%s", filename);
        *in = fopen (filename, "r");
        fileCheckerIN = checkFile(filename, *in, 'i');
        if(fileCheckerIN == 0)
            fclose(*in);
    }while(fileCheckerIN != 1);

    /*Open out*/
    do{
        printf ("Enter the name of the output file: ");
        scanf ("%s", filename);
        *out = fopen (filename, "w");
        fileCheckerOUT = checkFile(filename, *out, 'o');
        if(fileCheckerOUT == 0)
            fclose(*out);
    }while(fileCheckerOUT != 1);
}

/*checkFile - checks that the file meets certain parameters.*/
int checkFile(const char filename[], FILE *file, char fileType){
    /*Check for nonexistent file*/
    if(file == NULL){
    printf ("Error: unable to open file %s\n", filename);
    return 0;
    }

    /*Check for correct extension.*/
    char *extension;
    char correctExtension[MAXEXTENSION] = ".ppm";
    extension = strrchr(filename, '.');

    if(extension == NULL){
    printf ("Error: unable to open file %s\n", filename);
        return 0;
    }

    int string = strcmp(extension, correctExtension);
    if(string > 0 || string < 0){
        printf("Error: %s is not a PPM image file\n", filename);
        return 0;
    }

    /*Check for file header.*/
    if(fileType == 'i'){
        char header[MAXSTRING];
        char correctHeader[MAXSTRING] = "P3";
        fscanf(file, "%s", header);
        if(strcmp(header, correctHeader)==0 && string == 0)
            return 1;
        else{
            printf("Error: %s is not a PPM image file (Invalid file header)\n", filename);
            return 0;
        }
    }
    if(fileType == 'o')
        return 1;

    return 0;
}

/*processFile - reads in the image and writes out the translated image.*/
void processFile(FILE *in, FILE *out){
    static pixelT picture[ROWMAX][COLMAX];
    static pixelT rotatedPicture[ROWMAX][COLMAX];
    int columns, rows, maxColor;
    /*read image in*/
    readImage(in, picture, &columns, &rows, &maxColor);
    /*transpose it*/
    transposeImage(picture, rotatedPicture, rows, columns);
    /*print the file header*/
    printFileHeader(out, maxColor, rows, columns);
    /*write to the output file*/
    writeImage(out, rotatedPicture, rows, columns);
}

/*readImage - reads the input .ppm file in.*/
void readImage(FILE *file, pixelT image[][COLMAX], int *cols, int *row, int *maxCol){
    fscanf(file, " %d %d %d", cols, row, maxCol);
    printf("made it\n");
    int i, j;
    for(i = 0; i < *row; i++){
        for(j = 0; j < *cols; j++){
            fscanf (file, " %d %d %d", &image[i][j].red,
            &image[i][j].green, &image[i][j].blue);
        }
    }
}

/*printFileHeader - prints file header to output file.*/
void printFileHeader(FILE *out, int maxColor, int cols, int rows){
    fprintf(out, "P3\n%d %d\n%d\n", cols, rows, maxColor);
}

/*transposeImage - rotates the image.*/
void transposeImage(pixelT image[][COLMAX], pixelT rotatedImage[][COLMAX], int cols, int rows){
    int i,j;
    for(i = 0; i < rows; i++){
        for(j = 0; j < cols; j++){
            rotatedImage[i][j] = image[j][i];
        }
    }
}

void writeImage(FILE *out, pixelT image[][COLMAX], int cols, int rows){
    int i,j;
    for(i = 0; i < rows; i++){
        for(j = 0; j < cols; j++){
            fprintf(out, "%d %d %d\n", image[i][j].red, image[i][j].green, image[i][j].blue);
        }
    }
}
