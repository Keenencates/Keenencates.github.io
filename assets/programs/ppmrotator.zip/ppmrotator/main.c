/*File: main.c
 *Description: Transform
 *
 *----------------------------------------------------
 *Class: CS 210            Instructor: Dr. Deborah Hwang
 *Assignment:              Date assigned:
 *Programmer: Keenen Cates Date completed:
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAXEXTENSION 10
#define MAXSTRING 100
#define ROWMAX 500
#define COLMAX 500

typedef struct{
    int red, blue, green;
} pixelT;

/*Function Prototypes*/
void printGreeting(void);
void checkFile(const char filename[], FILE *file, char fileType);
void getFiles (FILE **in, FILE **out);
void writeImage(FILE *out, pixelT image[][COLMAX], int cols, int rows);
void printFileHeader(FILE *out, int maxColor, int cols, int rows);
void readImage(FILE *in, pixelT image[][COLMAX], int *cols, int *rows, int *maxColor );
void transposeImage(pixelT image[][COLMAX], pixelT rotatedImage[][COLMAX], int cols, int rows);
void processFile(FILE *in, FILE *out);

int main(void){
    FILE *inputFile, *outputFile;
    /*1. Greet the user.*/
    printGreeting();
    /*2. Get them files.*/
    getFiles(&inputFile, &outputFile);
    /*3. Process the file.*/
    processFile(inputFile, outputFile);
    /*4. Close files.*/
    fclose(inputFile);
    fclose(outputFile);
    /*5. Return 0.*/
    return 0;
}

/*printGreeting - prints the program banner.*/
void printGreeting(void){
    printf("PPM Image Rotator\n");
}

/*getFiles - opens input and output files.
Rec'd: input file, output file
P'back: input, output
*/
void getFiles (FILE **in, FILE **out){
    char filename[FILENAME_MAX];
    /*Open in*/
    printf ("Enter the name of a PPM image file: ");
    scanf ("%s", filename);
    *in = fopen (filename, "r");
    checkFile(filename, *in, 'i');

    /*Open out*/
    printf ("Enter the name of the output file: ");
    scanf ("%s", filename);
    *out = fopen (filename, "w");
    checkFile(filename, *out, 'o');
}

/*checkFile - checks that the file meets certain parameters.*/
void checkFile(const char filename[], FILE *file, char fileType){
    /*Check for nonexistent file*/
    if(file == NULL){
    printf ("Error: unable to open file %s\n", filename);
    exit(1);
    }

    /*Check for correct extension.*/
    char *extension;
    char correctExtension[MAXEXTENSION] = ".ppm";
    extension = strrchr(filename, '.');

    if(extension == NULL){
    printf ("Error: unable to open file %s\n", filename);
        exit(1);
    }

    int string = strcmp(extension, correctExtension);
    if(string > 0 || string < 0){
        printf("Error: %s is not a PPM image file\n", filename);
        exit(1);
    }

    /*Check for file header.*/
    if(fileType == 'i'){
        char header[MAXSTRING];
        char correctHeader[MAXSTRING] = "P3";
        fscanf(file, "%s", header);
        if(strcmp(header, correctHeader)!=0){
            printf("Error: %s is not a PPM image file (Invalid file header)\n", filename);
            exit(1);
        }
    }
}

/*processFile - reads in the image and writes out the translated image.*/
void processFile(FILE *in, FILE *out){
    static pixelT picture[ROWMAX][COLMAX];
    static pixelT rotatedPicture[ROWMAX][COLMAX];
    int columns, rows, maxColor;
    /*read image in*/
    readImage(in, picture, &columns, &rows, &maxColor);
    /*transpose it*/
    transposeImage(picture, rotatedPicture, rows, columns);
    /*print the file header*/
    printFileHeader(out, maxColor, rows, columns);
    /*write to the output file*/
    writeImage(out, rotatedPicture, rows, columns);
}

/*readImage - reads the input .ppm file in.*/
void readImage(FILE *file, pixelT image[][COLMAX], int *cols, int *row, int *maxCol){
    fscanf(file, " %d %d %d", cols, row, maxCol);
    int i, j;
    for(i = 0; i < *row; i++){
        for(j = 0; j < *cols; j++){
            fscanf (file, " %d %d %d", &image[i][j].red,
            &image[i][j].green, &image[i][j].blue);
        }
    }
}

/*printFileHeader - prints file header to output file.*/
void printFileHeader(FILE *out, int maxColor, int cols, int rows){
    fprintf(out, "P3\n%d %d\n%d\n", cols, rows, maxColor);
}

/*transposeImage - rotates the image.*/
void transposeImage(pixelT image[][COLMAX], pixelT rotatedImage[][COLMAX], int cols, int rows){
    int i,j;
    for(i = 0; i < rows; i++){
        for(j = 0; j < cols; j++){
            rotatedImage[i][j] = image[j][i];
        }
    }
}

void writeImage(FILE *out, pixelT image[][COLMAX], int cols, int rows){
    int i,j;
    for(i = 0; i < rows; i++){
        for(j = 0; j < cols; j++){
            fprintf(out, "%d %d %d\n", image[i][j].red, image[i][j].green, image[i][j].blue);
        }
    }
}
