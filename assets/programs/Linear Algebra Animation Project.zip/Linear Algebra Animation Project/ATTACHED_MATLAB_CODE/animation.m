M = [1 2 2 1 1; 1 1 2 2 1; 1 1 1 1 1];
X = [1 2 2 1 1; 1 1 2 2 1; 1 1 1 1 1];
theta = pi/8;
figure, plot(M(1,:), M(2,:), 'b-.', M(1,:), M(2,:), '*m'),
axis([-10, 10, -10, 10]); hold on
plot(X(1,:), X(2,:), '--g', X(1,:), X(2,:), 'xr')
TransOrgin=[1 0 2; 0 1 1; 0 0 1];
TransBack=[1 0 -1; 0 1 -1; 0 0 1];
RotMatrix=[cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];
DilMatrix=[1.01 0 0; 0 1.01 0; 0 0 1];
CompositionMatrix=TransBack*DilMatrix*RotMatrix*TransOrgin;
for i = 1:64
    M = CompositionMatrix*M;
    pause(.08)
    plot(M(1,:), M(2,:), '-.', M(1,:), M(2,:), '*m'),
    X = CompositionMatrix*X;
    Mov(i) = getframe;
    pause(.08)
    plot(X(1,:), X(2,:), '--g', X(1,:), X(2,:), 'xr'), hold on
end