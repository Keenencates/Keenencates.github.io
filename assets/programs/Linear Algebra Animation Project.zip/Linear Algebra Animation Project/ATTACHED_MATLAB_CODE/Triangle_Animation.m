%%Keenen Cates
%%Moving Triangle Example
triangle = [0, 0.5, 1; 0, 1.5, 0];
%%1. Create the figure and axis then hold on.
figure
hold on;
axis([-20 20 -20 20]);

%%2. Create the triangles.
triangleCenter = triangle;
triangleOuter = triangle;

%%3. Draw initial triangles.
triangleCenterHandle = fill(triangleCenter(1,:), triangleCenter(2,:), 'b');
triangleOuterHandle = fill(triangleOuter(1,:), triangleOuter(2,:), 'r');

%%4. For 100 frames transform the matrix.
for i=1:150
    %%4.1. Remove previous ship from frame.
    delete(triangleCenterHandle);
    delete(triangleOuterHandle);
    
    %%4.2. Calculate rotation.
    theta = i*pi/180;
    rotationFactorCenter = [cos(theta), -sin(theta);
                            sin(theta),  cos(theta)];
    %%4.3. Change rotation with negative theta.
    rotationFactorOuter = [cos(-theta), -sin(-theta);
                           sin(-theta),  cos(-theta)];
    %%4.4. Dialate the outer triangle's location.
    triangleOuter = 1.01 * triangleOuter;
    %%4.5. Translate outer triangle by .1.
    triangleOuter = triangleOuter + 0.1;
    %%4.6. Get new triangle.
    triangleCenterRot = rotationFactorCenter*triangleCenter;
    triangleOuterRot = rotationFactorOuter*triangleOuter;
    %%4.7. Plot the rotated coords.
    triangleCenterHandle = fill(triangleCenterRot(1,:), triangleCenterRot(2,:), 'b');
    triangleOuterHandle = fill(triangleOuterRot(1,:), triangleOuterRot(2,:), 'r');
    %%4.8. Pause for animation and get frame.
    Mov(i) = getframe;
    pause(0.05);
end
    
