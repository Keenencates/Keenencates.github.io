%%Matlab Trial Code
x = 0;
x = 0:0.01:2;
y = x;
plot(x,y)
hold on
axis([-2 4 -2 4])
B = [cos(pi/6) -sin(pi/6); sin(pi/6) cos(pi/6)];
% B is a vector the will rotate each vector 30 degrees.
V = [x;y];
y = x;
V = [x;y];
Y = B*V;

% Y is a matrix with row1 = x values of the rotated line.
% and row2 = y values of the rotated line.

%Y(n,m) = the nth row, nth column entry of Y so Y(1,:) give the entire
% first row of entries and Y(:,3) gives the entire 3rd column of entries
%and Y(3,4) gives the single entry in row three column 4.
plot(Y(1,:),Y(2,:))