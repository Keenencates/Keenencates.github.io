package com.boardgames.engine.utils;

public interface Command {

	public void apply();
	
}
