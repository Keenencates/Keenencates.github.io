package com.boardgames.gui;

import javax.swing.JPanel;

public class HexPanel extends JPanel {

	public HexPanel() {
	}

	private static final long serialVersionUID = -6310156430143620936L;

}
