package com.boardgames.engine.utils;

public interface Observer {

	public void update();
	
}
